ESX Show IDs - Solo ID / Pricedown

Descripción:
Plugin para FiveM/ESX que permite mostrar y ocultar los IDs de jugadores cercanos usando el comando /id, sin mostrar nombres de jugadores.

Funcionalidades:
- Mostrar u ocultar IDs con /id.
- Muestra únicamente el ID sobre la cabeza del jugador.
- Usa la fuente Pricedown Regular / estilo GTA mediante Config.TextFont = 7.
- Tu propio ID se muestra en verde claro.
- Los demás jugadores se muestran en azul.
- Los jugadores hablando por voz se muestran en rojo.
- Compatibilidad adicional con pma-voice.
- Simulación de línea de visión para evitar ver IDs a través de paredes.
- Escalado dinámico del texto según la distancia.
- Fondo de etiqueta oculto por defecto.
- Fondo semitransparente configurable desde shared/config.lua.
- Distancia configurable desde shared/config.lua.
- Caché de jugadores cercanos para mejorar el rendimiento.

Configuración del fondo:
Por defecto:
Config.Tag.Background = false

Para activar el fondo:
Config.Tag.Background = true

Instalación:
1. Coloca la carpeta esx_showids en tus resources.
2. Añade ensure esx_showids en tu server.cfg.
3. Reinicia el servidor o ejecuta refresh y ensure esx_showids.
