ESX Show IDs - Only ID / Pricedown

Description:
FiveM/ESX plugin that lets players show and hide nearby player IDs using the /id command, without displaying player names.

Features:
- Toggle IDs with /id.
- Displays only the server ID above each player.
- Uses the Pricedown Regular / GTA-style font through Config.TextFont = 7.
- Your own ID is shown in light green.
- Other players are shown in blue.
- Voice-active players are shown in red.
- Additional pma-voice compatibility.
- Line-of-sight simulation to prevent seeing IDs through walls.
- Dynamic text scaling based on distance.
- Tag background hidden by default.
- Optional semi-transparent background configurable through shared/config.lua.
- Configurable distance through shared/config.lua.
- Nearby-player caching for better performance.

Background configuration:
Default:
Config.Tag.Background = false

To enable the background:
Config.Tag.Background = true

Installation:
1. Place the esx_showids folder inside your resources.
2. Add ensure esx_showids to your server.cfg.
3. Restart the server or run refresh and ensure esx_showids.
