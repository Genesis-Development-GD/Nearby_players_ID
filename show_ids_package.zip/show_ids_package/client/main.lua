local showIDs = false
local nearbyPlayers = {}
local lastRefresh = 0

local function DebugPrint(message)
    if Config.Debug then
        print(('[esx_showids] %s'):format(message))
    end
end

local function Notify(message)
    if not Config.Notify.Enabled then
        return
    end

    if ESX and ESX.ShowNotification then
        ESX.ShowNotification(message)
    else
        BeginTextCommandThefeedPost('STRING')
        AddTextComponentSubstringPlayerName(message)
        EndTextCommandThefeedPostTicker(false, true)
    end
end

RegisterCommand(Config.Command, function()
    showIDs = not showIDs

    if showIDs then
        Notify(Config.Notify.On)
    else
        Notify(Config.Notify.Off)
    end
end, false)

local function ShouldRenderIds()
    if Config.HoldKey.Enabled and IsControlPressed(0, Config.HoldKey.Key) then
        return true
    end

    return showIDs
end

local function RefreshNearbyPlayers()
    local now = GetGameTimer()

    if now - lastRefresh < Config.RefreshNearbyPlayers then
        return
    end

    lastRefresh = now
    nearbyPlayers = {}

    local myPed = PlayerPedId()
    local myCoords = GetEntityCoords(myPed)

    for _, player in ipairs(GetActivePlayers()) do
        local targetPed = GetPlayerPed(player)

        if DoesEntityExist(targetPed) then
            if not Config.HideDeadPlayers or not IsEntityDead(targetPed) then
                local targetCoords = GetEntityCoords(targetPed)
                local dist = #(myCoords - targetCoords)

                if dist <= Config.Distance then
                    nearbyPlayers[#nearbyPlayers + 1] = {
                        player = player,
                        ped = targetPed,
                        coords = targetCoords,
                        distance = dist,
                        serverId = GetPlayerServerId(player)
                    }
                end
            end
        end
    end

    DebugPrint(('Nearby players: %s'):format(#nearbyPlayers))
end

local function IsPMATalking(player, serverId)
    if not Config.PMAVoiceSupport then
        return false
    end

    if GetResourceState('pma-voice') ~= 'started' then
        return false
    end

    local playerState = Player(serverId).state

    if not playerState then
        return false
    end

    if playerState.isTalking == true then
        return true
    end

    if playerState.talking == true then
        return true
    end

    if Config.PMARadioSupport then
        if playerState.radioTalking == true then
            return true
        end

        if playerState.isRadioTalking == true then
            return true
        end
    end

    return false
end

local function IsPlayerTalkingAdvanced(player, serverId)
    if NetworkIsPlayerTalking(player) then
        return true
    end

    return IsPMATalking(player, serverId)
end

local function GetIDColor(player, myPlayer, serverId)
    if IsPlayerTalkingAdvanced(player, serverId) then
        return Config.Colors.Talking
    end

    if player == myPlayer then
        return Config.Colors.Own
    end

    return Config.Colors.Other
end

local function GetIDScale(distance)
    if not Config.UseDynamicScale then
        return Config.MaxScale
    end

    local percent = 1.0 - (distance / Config.Distance)
    local scale = Config.MinScale + ((Config.MaxScale - Config.MinScale) * percent)

    if scale < Config.MinScale then
        scale = Config.MinScale
    elseif scale > Config.MaxScale then
        scale = Config.MaxScale
    end

    return scale
end

local function HasLineOfSight(myPed, targetPed, player, myPlayer)
    if not Config.UseLineOfSight then
        return true
    end

    if Config.AlwaysShowOwnId and player == myPlayer then
        return true
    end

    return HasEntityClearLosToEntity(myPed, targetPed, 17)
end

local function GetDisplayText(serverId)
    return tostring(serverId)
end

local function DrawText3D(x, y, z, text, color, scale)
    local onScreen, screenX, screenY = World3dToScreen2d(x, y, z)

    if not onScreen then
        return
    end

    SetTextScale(scale, scale)
    SetTextFont(Config.TextFont or 7)
    SetTextProportional(1)
    SetTextCentre(true)

    BeginTextCommandWidth('STRING')
    AddTextComponentSubstringPlayerName(text)
    local textWidth = EndTextCommandGetWidth(Config.TextFont or 7)

    if Config.Tag.Background then
        local bg = Config.Tag.BackgroundColor

        DrawRect(
            screenX,
            screenY + Config.Tag.BackgroundYOffset,
            textWidth + Config.Tag.BackgroundPadding,
            Config.Tag.BackgroundHeight,
            bg.r,
            bg.g,
            bg.b,
            bg.a
        )
    end

    SetTextColour(color.r, color.g, color.b, color.a or 255)
    SetTextOutline()

    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(screenX, screenY)
end

CreateThread(function()
    while true do
        local sleep = 500

        if ShouldRenderIds() then
            sleep = 0

            RefreshNearbyPlayers()

            local myPed = PlayerPedId()
            local myCoords = GetEntityCoords(myPed)
            local myPlayer = PlayerId()

            for _, data in ipairs(nearbyPlayers) do
                if DoesEntityExist(data.ped) and HasLineOfSight(myPed, data.ped, data.player, myPlayer) then
                    local coords = GetEntityCoords(data.ped)
                    local dist = #(myCoords - coords)

                    if dist <= Config.Distance then
                        local color = GetIDColor(data.player, myPlayer, data.serverId)
                        local scale = GetIDScale(dist)
                        local text = GetDisplayText(data.serverId)

                        DrawText3D(
                            coords.x,
                            coords.y,
                            coords.z + Config.TextHeight,
                            text,
                            color,
                            scale
                        )
                    end
                end
            end
        end

        Wait(sleep)
    end
end)
