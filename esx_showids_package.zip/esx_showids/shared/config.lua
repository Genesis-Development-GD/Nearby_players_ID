Config = {}

-- Main command
Config.Command = 'id'

-- Maximum distance to show IDs
Config.Distance = 15.0

-- Refresh nearby players every X ms.
-- Lower = more updated, higher = better performance.
Config.RefreshNearbyPlayers = 500

-- Line of sight simulation to prevent seeing IDs through walls
Config.UseLineOfSight = true

-- Dynamic text scaling based on distance
Config.UseDynamicScale = true
Config.MinScale = 0.25
Config.MaxScale = 0.42

-- Text height above player
Config.TextHeight = 1.10

-- Tag visual settings
Config.Tag = {
    Background = true,
    BackgroundPadding = 0.018,
    BackgroundHeight = 0.032,
    BackgroundYOffset = 0.012,
    BackgroundColor = { r = 0, g = 0, b = 0, a = 125 }
}

-- Colors
Config.Colors = {
    Own = { r = 144, g = 238, b = 144, a = 255 },      -- Own ID: light green
    Other = { r = 0, g = 150, b = 255, a = 255 },      -- Other players: blue
    Talking = { r = 255, g = 0, b = 0, a = 255 }       -- Talking player: red
}

-- pma-voice support.
-- Does not replace NetworkIsPlayerTalking; it is only used as extra support if state bags are available.
Config.PMAVoiceSupport = true

-- Show as talking if the player is talking on radio.
-- Depends on whether your pma-voice version/config exposes that state bag.
Config.PMARadioSupport = true

-- Notifications
Config.Notify = {
    Enabled = true,
    On = 'IDs activados',
    Off = 'IDs desactivados'
}

-- Optional hold key mode.
-- If Enabled = true, IDs can also be shown while holding this key.
Config.HoldKey = {
    Enabled = false,
    Key = 19 -- Left ALT by default in FiveM
}

-- Always show your own ID even if line of sight check is enabled
Config.AlwaysShowOwnId = true

-- Hide dead players
Config.HideDeadPlayers = false

-- Debug mode
Config.Debug = false
