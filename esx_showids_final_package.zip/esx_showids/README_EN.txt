ESX Show IDs

Description:
FiveM/ESX plugin that lets players show and hide nearby player IDs using the /id command.

Features:
- Toggle IDs with /id.
- Displays name + ID above each player.
- Your own ID is shown in light green.
- Other players are shown in blue.
- Voice-active players are shown in red.
- Additional pma-voice compatibility.
- Line-of-sight simulation to prevent seeing IDs through walls.
- Dynamic text scaling based on distance.
- Semi-transparent background behind the text.
- Configurable distance through shared/config.lua.
- Nearby-player caching for better performance.

Installation:
1. Place the esx_showids folder inside your resources.
2. Add ensure esx_showids to your server.cfg.
3. Restart the server or run refresh and ensure esx_showids.
