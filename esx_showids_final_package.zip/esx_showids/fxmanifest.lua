fx_version 'cerulean'
game 'gta5'

author 'ChatGPT'
description 'ESX Show IDs - Name + ID, voice colors, line of sight and optimization'
version '2.1.0'

lua54 'yes'

shared_scripts {
    'shared/config.lua'
}

client_scripts {
    'client/main.lua'
}
