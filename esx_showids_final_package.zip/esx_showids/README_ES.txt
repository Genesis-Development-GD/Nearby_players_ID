ESX Show IDs

Descripción:
Plugin para FiveM/ESX que permite mostrar y ocultar los IDs de jugadores cercanos usando el comando /id.

Funcionalidades:
- Mostrar u ocultar IDs con /id.
- Muestra nombre + ID sobre la cabeza del jugador.
- Tu propio ID se muestra en verde claro.
- Los demás jugadores se muestran en azul.
- Los jugadores hablando por voz se muestran en rojo.
- Compatibilidad adicional con pma-voice.
- Simulación de línea de visión para evitar ver IDs a través de paredes.
- Escalado dinámico del texto según la distancia.
- Fondo semitransparente detrás del texto.
- Distancia configurable desde shared/config.lua.
- Caché de jugadores cercanos para mejorar el rendimiento.

Instalación:
1. Coloca la carpeta esx_showids en tus resources.
2. Añade ensure esx_showids en tu server.cfg.
3. Reinicia el servidor o ejecuta refresh y ensure esx_showids.
