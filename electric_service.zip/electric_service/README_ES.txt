ELECTRIC SERVICE - README EN ESPANOL
====================================

Descripcion general
-------------------
Electric Service simula una red electrica para el mapa. El mapa se divide en circuitos de zona con diferente prioridad, peso economico, densidad poblacional y clase social. Tambien incluye facturacion mensual por propiedades, cortes por deuda y gameplay de reparacion para tecnicos electricistas.

La regla principal de energia es:
Propiedad con luz = circuito de zona con luz + propiedad sin deuda vencida.

Esto significa que el circuito virtual de deuda nunca cambia el estado de los circuitos de zona. Si una zona esta apagada por averia, la propiedad no tiene luz aunque el jugador haya pagado. Si la zona tiene luz, pero la propiedad tiene deuda vencida, solo esa propiedad queda sin electricidad.

Features principales
--------------------
1. Circuitos electricos de zona
   Divide el mapa en circuitos configurables. Cada circuito tiene subestacion, prioridad, carga, salud, clase social y zonas GTA asociadas.

2. Clases sociales por precio de vivienda
   Cada zona puede clasificarse como economica, clase baja, clase media o clase alta usando el precio base de vivienda configurado en el circuito.

3. Apagones por averia
   El servidor puede generar fallas automaticas por carga, salud del circuito o eventos aleatorios. Los circuitos apagados por averia necesitan reparacion.

4. Cortes y restauraciones administrativas
   Los administradores pueden cortar, restaurar o poner en mantenimiento un circuito de zona usando comandos.

5. Subestaciones con marcadores
   Cada circuito tiene una subestacion. Los marcadores permiten a los tecnicos encontrar y reparar circuitos apagados.

6. Job de tecnico electricista
   Los jugadores con job electrician pueden reparar subestaciones apagadas o danadas. El servidor valida job, distancia, item opcional y estado del circuito.

7. App de facturas para jugadores
   Los jugadores pueden abrir una app sencilla de telefono para ver sus propiedades, dias restantes, monto pendiente, boton de pago y pago automatico.

8. Facturacion mensual por propiedad
   Cada vivienda o negocio puede tener una cuota mensual segun clase social, circuito, zona GTA o configuracion especial del servidor.

9. Cortes por deuda en propiedades
   Si una factura vence, se bloquea la electricidad de la propiedad usando un circuito virtual de deuda. Este circuito es solo informativo y no modifica la zona.

10. Pago automatico
    El jugador puede activar un toggle para intentar pagar automaticamente el dia 1 de cada mes del juego.

11. App tecnica para electricistas
    Los tecnicos electricistas tienen una app separada donde ven circuitos de zona apagados por averia. La app incluye un boton para crear ruta de reparacion.

12. Ruta de reparacion en minimapa
    La app tecnica marca la primera subestacion como ruta GPS y agrega marcadores en el minimapa para todas las subestaciones apagadas por averia.

13. Persistencia en JSON
    El estado de la red y la facturacion se guardan en archivos JSON para facilitar instalacion y pruebas.

14. Exports para integraciones
    Otros recursos pueden consultar si un circuito o propiedad tiene electricidad, registrar propiedades, abrir apps o pagar facturas desde codigo.

Roles y uso
-----------

JUGADOR / CIVIL
~~~~~~~~~~~~~~~
Que puede hacer:
- Ver el estado electrico de la zona actual.
- Ver el estado de todos los circuitos principales.
- Abrir la app de facturas.
- Pagar facturas pendientes.
- Activar o desactivar pago automatico.
- Ver si sus propiedades tienen luz o estan cortadas por deuda.

Comandos:
/circuito
Muestra la zona actual, circuito, clase social, precio base de vivienda, carga, salud y si hay electricidad.

/redluz
Muestra un resumen de los circuitos principales.

/subestacion
Marca en el GPS la subestacion del circuito actual.

/subestacion <circuito>
Marca en el GPS la subestacion de un circuito especifico.
Ejemplo: /subestacion LS-CENTRO

/luzapp
Abre la app de facturas del jugador.

App de facturas:
- Muestra el total pendiente.
- Muestra los dias restantes para pagar.
- Permite pagar la factura pendiente.
- Permite activar pago automatico el dia 1.
- Lista viviendas y negocios registrados.
- Muestra si una propiedad tiene luz o esta sin servicio.

TECNICO ELECTRICISTA
~~~~~~~~~~~~~~~~~~~~
Que puede hacer:
- Ver circuitos apagados por averia desde una app tecnica.
- Crear una ruta de reparacion hacia subestaciones con fallas.
- Reparar circuitos desde la subestacion.
- Recibir pago por reparaciones si esta configurado.

Requisito:
- Tener el job configurado en Config.ElectricianJobs. Por defecto: electrician.

Comandos:
/luztecnico
Abre la app tecnica para electricistas. Solo muestra circuitos de zona apagados por averia y que requieren reparacion.

/luzruta_clear
Elimina los marcadores de ruta tecnica creados por la app.

Uso de la app tecnica:
- Abre /luztecnico.
- Revisa la lista de circuitos apagados por averia.
- Pulsa "Marcar ruta de reparacion" para crear ruta y marcadores.
- Ve a la subestacion marcada.
- Presiona E sobre el marcador de la subestacion para reparar.

Reparacion:
- El servidor valida que el jugador sea tecnico.
- El servidor valida distancia a la subestacion.
- Puede requerir un item si se configura en Config.Repair.requiredItem.
- Al completar la reparacion, el circuito vuelve a estar online.

ADMINISTRADOR
~~~~~~~~~~~~~
Que puede hacer:
- Crear cortes manuales.
- Restaurar circuitos.
- Activar o desactivar mantenimiento.
- Revisar estado general de la red.
- Registrar propiedades a jugadores.
- Eliminar propiedades del sistema electrico.
- Revisar facturas y deuda de jugadores.

Permiso:
ACE recomendado:
add_ace group.admin electric_service.admin allow

Comandos:
/corte <circuito|zona> [minutos] [motivo]
Apaga un circuito de zona. Por defecto requiere reparacion.
Ejemplo: /corte LS-CENTRO 30 Falla en transformador

/restaurar <circuito|zona>
Restaura un circuito de zona.
Ejemplo: /restaurar LS-CENTRO

/mantenimiento <circuito|zona> <on|off> [minutos] [motivo]
Activa o desactiva mantenimiento de un circuito.
Ejemplo: /mantenimiento COSTA-OESTE on 20 Revision preventiva
Ejemplo: /mantenimiento COSTA-OESTE off

/electricidad_estado
Muestra el estado general de los circuitos.

/electricidad_prop_add <idJugador> <house|business> <propiedadId> <zonaGTA> [nombre]
Registra una vivienda o negocio para facturacion electrica.
Ejemplo: /electricidad_prop_add 12 house apt_001 ALTA Apartamento Centro

/electricidad_prop_remove <propiedadId>
Elimina una propiedad del sistema electrico.
Ejemplo: /electricidad_prop_remove apt_001

/electricidad_prop_estado <propiedadId>
Muestra informacion electrica de una propiedad.
Ejemplo: /electricidad_prop_estado apt_001

/electricidad_facturas <idJugador|identifier>
Muestra deuda, autopago y propiedades de un jugador.
Ejemplo: /electricidad_facturas 12

DESARROLLADOR / INTEGRADOR
~~~~~~~~~~~~~~~~~~~~~~~~~~~
Que puede hacer:
- Integrar housing, negocios, interiores, telefono o tiendas.
- Consultar si una zona o propiedad tiene luz.
- Registrar propiedades desde otro recurso.
- Abrir la app de facturas o app tecnica desde un telefono personalizado.

Eventos cliente utiles:
TriggerEvent('electric_service:client:openPhoneApp')
Abre la app de facturas.

TriggerEvent('electric_service:client:openElectricianApp')
Abre la app tecnica para jugadores con job electrician.

TriggerEvent('electric_service:client:enterProperty', 'apt_001')
Indica que el jugador entro a una propiedad. Sirve para aplicar corte local por deuda.

TriggerEvent('electric_service:client:exitProperty')
Indica que el jugador salio de la propiedad actual.

Exports cliente:
exports['electric_service']:HasPower()
Devuelve si el jugador tiene electricidad en su zona o propiedad actual.

exports['electric_service']:OpenPhoneApp()
Abre la app de facturas.

exports['electric_service']:OpenElectricianApp()
Abre la app tecnica.

exports['electric_service']:ClearRepairRoute()
Limpia los marcadores de ruta tecnica.

exports['electric_service']:EnterProperty('apt_001')
Marca la propiedad actual.

exports['electric_service']:ExitProperty()
Limpia la propiedad actual.

Exports servidor:
exports['electric_service']:IsCircuitPowered('LS-CENTRO')
Consulta si un circuito de zona tiene luz.

exports['electric_service']:SetCircuitOffline('LS-CENTRO', 15, 'Falla externa', true)
Apaga un circuito por codigo.

exports['electric_service']:SetCircuitOnline('LS-CENTRO', 'Restaurado')
Restaura un circuito por codigo.

exports['electric_service']:RegisterProperty({ id = 'apt_001', label = 'Apartamento 001', owner = 'license:xxxxxxxx', type = 'house', zoneCode = 'ALTA' })
Registra una propiedad para facturacion.

exports['electric_service']:IsPropertyPowered('apt_001')
Consulta si una propiedad tiene electricidad segun circuito de zona y deuda.

exports['electric_service']:GetRepairOutages()
Devuelve los circuitos de zona apagados por averia y pendientes de reparacion.

Configuracion importante
------------------------
Config.Circuits
Define circuitos, zonas GTA, subestaciones, prioridad, carga, clase y precio base de vivienda.

Config.HousingClasses
Define los rangos de precios para economica, baja, media y alta.

Config.Billing.feesByClass
Define cuotas por clase y tipo de propiedad.

Config.Billing.feesByCircuit
Permite cuotas especiales por circuito.

Config.Billing.feesByZone
Permite cuotas especiales por zona GTA.

Config.Billing.invoice.deadlineDays
Define el plazo de pago mensual en dias del juego.

Config.Billing.debtCircuit
Configura el circuito virtual de deuda. No afecta circuitos de zona.

Config.Repair
Configura tiempo de reparacion, item requerido, pago y distancia maxima.

Config.RepairApp
Configura la app tecnica, ruta y marcadores de reparacion.

Instalacion basica
------------------
1. Copia la carpeta electric_service en resources/[local]/electric_service.
2. Asegura que el framework base cargue antes del recurso.
3. Agrega en server.cfg:

ensure es_extended
ensure electric_service

4. Opcionalmente ejecuta INSTALL.sql para crear job e item de reparacion.
5. Ajusta config.lua a la economia y sistema de viviendas de tu servidor.

Notas finales
-------------
- Los cortes por deuda son por propiedad, no por zona.
- Los apagones por averia son por circuito de zona.
- La app tecnica solo lista circuitos reales de zona apagados por averia.
- El circuito virtual de deuda no aparece como circuito reparable.
