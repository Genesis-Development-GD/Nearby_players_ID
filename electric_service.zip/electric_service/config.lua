Config = {}

Config.Debug = false
Config.ResourceName = 'electric_service'

-- Main framework resource. The script uses the modern shared-object export.
Config.Framework = {
    resource = 'es_extended'
}

-- If true, the social class is inferred from housingBasePrice.
-- You can still force a class per circuit with class = 'alta', etc.
Config.UsePriceClassInference = true

-- Social/economic classes based on approximate housing values.
-- Change ranges to match your server economy or housing script.
Config.HousingClasses = {
    economica = {
        label = 'Zona economica',
        min = 0,
        max = 199999,
        demandMultiplier = 0.75,
        billMultiplier = 0.70,
        reliability = 0.82,
        description = 'Vivienda muy barata, zonas rurales, industriales o de bajo coste.'
    },
    baja = {
        label = 'Clase baja',
        min = 200000,
        max = 349999,
        demandMultiplier = 0.92,
        billMultiplier = 0.85,
        reliability = 0.86,
        description = 'Barrios residenciales populares con alta densidad.'
    },
    media = {
        label = 'Clase media',
        min = 350000,
        max = 749999,
        demandMultiplier = 1.08,
        billMultiplier = 1.00,
        reliability = 0.91,
        description = 'Zonas residenciales y comerciales mixtas.'
    },
    alta = {
        label = 'Clase alta',
        min = 750000,
        max = 999999999,
        demandMultiplier = 1.25,
        billMultiplier = 1.35,
        reliability = 0.95,
        description = 'Barrios premium, turismo de alto valor y mansiones.'
    }
}

-- Job allowed to repair circuits.
-- Format: jobName = minimumGrade
Config.ElectricianJobs = {
    electrician = 0
}

Config.Admin = {
    ace = 'electric_service.admin',
    frameworkGroups = {
        admin = true,
        superadmin = true
    }
}

Config.Persistence = {
    enabled = true,
    file = 'data/grid_state.json',
    saveEverySeconds = 120
}

Config.FallbackCircuit = 'LS-CENTRO'

Config.Visual = {
    updateSeconds = 3,
    localBlackout = true,
    notifyWhenCircuitChanges = true,
    notifyWhenPowerChanges = true,
    showSubstationBlips = true,
    showOnlyOfflineBlips = false
}

Config.Blips = {
    substation = {
        sprite = 354,
        scale = 0.70,
        colorOnline = 2,
        colorOffline = 1,
        colorMaintenance = 47,
        shortRange = true
    }
}

Config.Marker = {
    enabled = true,
    type = 1,
    drawDistance = 35.0,
    interactDistance = 2.5,
    size = vector3(1.25, 1.25, 0.55),
    colorOnline = { r = 0, g = 180, b = 80, a = 130 },
    colorOffline = { r = 220, g = 50, b = 50, a = 160 },
    colorMaintenance = { r = 250, g = 180, b = 40, a = 160 }
}

Config.Repair = {
    enabled = true,
    jobRequired = true,
    durationMs = 18000,
    maxDistance = 4.0,
    requiredItem = nil, -- Example: 'electric_repairkit'
    consumeItem = false,
    restoreHealth = 100,
    pay = {
        enabled = true,
        account = 'bank', -- money, bank, black_money
        base = 650,
        priorityBonus = 120,
        loadBonusDivider = 8
    }
}

Config.RepairApp = {
    enabled = true,
    commandEnabled = true,
    title = 'Panel tecnico electrico',
    description = 'Muestra circuitos de zona apagados por averia y crea rutas hacia sus subestaciones.',
    showOnlyFailureOutages = true,
    routeBlip = {
        sprite = 354,
        color = 5,
        routeColor = 5,
        scale = 0.85,
        shortRange = false
    }
}

Config.RandomEvents = {
    enabled = true,
    checkEveryMinutes = 15,
    chanceBase = 0.10,
    minOfflineMinutes = 12,
    maxOfflineMinutes = 45,
    requireRepair = true,
    respectPriority = true
}

Config.LoadModel = {
    refreshSeconds = 60,
    overloadDamageDivisor = 8,
    hourMultipliers = {
        [0] = 0.72, [1] = 0.68, [2] = 0.65, [3] = 0.63, [4] = 0.65, [5] = 0.72,
        [6] = 0.88, [7] = 1.08, [8] = 1.22, [9] = 1.14, [10] = 1.04, [11] = 1.02,
        [12] = 1.06, [13] = 1.08, [14] = 1.04, [15] = 1.08, [16] = 1.14, [17] = 1.28,
        [18] = 1.35, [19] = 1.30, [20] = 1.18, [21] = 1.05, [22] = 0.94, [23] = 0.82
    }
}

Config.Commands = {
    current = 'circuito',
    grid = 'redluz',
    substation = 'subestacion',
    adminOutage = 'corte',
    adminRestore = 'restaurar',
    adminMaintenance = 'mantenimiento',
    adminGrid = 'electricidad_estado',
    phoneApp = 'luzapp',
    adminPropertyAdd = 'electricidad_prop_add',
    adminPropertyRemove = 'electricidad_prop_remove',
    adminPropertyStatus = 'electricidad_prop_estado',
    adminBillingStatus = 'electricidad_facturas',
    electricianApp = 'luztecnico',
    clearRepairRoute = 'luzruta_clear'
}

-- Billing and property service.
-- This module never changes the status of the zone circuits in Config.Circuits.
-- Property power is calculated as: zone circuit powered AND property not cut by debt.
Config.Billing = {
    enabled = true,
    persistenceFile = 'data/billing_state.json',
    saveEverySeconds = 120,
    paymentAccount = 'bank', -- money, bank, black_money
    allowCashFallback = false,

    calendar = {
        daysPerMonth = 30,
        realSecondsPerGameDay = 300,
        startDay = 1,
        startMonth = 1,
        startYear = 2026
    },

    invoice = {
        deadlineDays = 30,
        autoPayDay = 1,
        graceOnRegistration = true,
        cutAllOwnerPropertiesOnDebt = false
    },

    propertyTypes = {
        house = 'Vivienda',
        business = 'Negocio'
    },

    -- Default monthly fees by social class and property type.
    feesByClass = {
        economica = { house = 120, business = 650 },
        baja = { house = 180, business = 900 },
        media = { house = 320, business = 1500 },
        alta = { house = 580, business = 2800 }
    },

    -- Optional overrides. Use circuit IDs or GTA zone codes when a sector needs custom prices.
    feesByCircuit = {
        -- ['LS-CENTRO'] = { house = 420, business = 2400 }
    },

    feesByZone = {
        -- ['ROCKF'] = { house = 750, business = 3500 }
    },

    debtCircuit = {
        prefix = 'DEBT',
        label = 'Circuito virtual de deuda',
        statusWhenDebt = 'offline',
        statusWhenClear = 'online'
    },

    app = {
        commandEnabled = true,
        title = 'Servicio electrico',
        showPropertyList = true
    },

    -- Optional static properties for servers without an external housing/business script.
    -- Each property may define: id, label, owner, type, zoneCode, circuitId, class, feeOverride.
    registeredProperties = {
        -- { id = 'apt_001', label = 'Apartamento 001', owner = 'license:xxxxxxxx', type = 'house', zoneCode = 'ALTA' }
    }
}

-- Circuit design notes:
-- priority: 1 critical, 5 low.
-- economicWeight and populationWeight: 0-100.
-- housingBasePrice is used to infer the class: economica, baja, media or alta.
-- zones use GTA/FiveM zone codes returned by GetNameOfZone.
Config.Circuits = {
    {
        id = 'LS-CENTRO',
        name = 'Centro financiero y administrativo',
        priority = 1,
        economicWeight = 98,
        populationWeight = 94,
        housingBasePrice = 520000,
        capacity = 138,
        baseLoad = 68,
        zones = { 'ALTA', 'BURTON', 'DOWNT', 'LEGSQU', 'PBOX', 'TEXTI', 'HAWICK', 'KOREAT', 'DTVINE' },
        substation = { label = 'Subestacion Centro', coords = vector3(236.18, -877.32, 30.49) }
    },
    {
        id = 'VINEWOOD-ALTA',
        name = 'Vinewood, Rockford y Richman',
        priority = 2,
        economicWeight = 82,
        populationWeight = 66,
        housingBasePrice = 1350000,
        capacity = 118,
        baseLoad = 54,
        zones = { 'CHIL', 'RICHM', 'RGLEN', 'ROCKF', 'GOLF', 'WVINE', 'VINE', 'MORN', 'MOVIE' },
        substation = { label = 'Subestacion Vinewood Norte', coords = vector3(-575.76, 529.89, 108.03) }
    },
    {
        id = 'COSTA-OESTE',
        name = 'Costa oeste, playa y turismo',
        priority = 2,
        economicWeight = 88,
        populationWeight = 76,
        housingBasePrice = 690000,
        capacity = 126,
        baseLoad = 59,
        zones = { 'BEACH', 'VESP', 'VCANA', 'DELPE', 'DELBE', 'DELSOL', 'LOSPUE', 'LOSPUER', 'PBLUFF' },
        substation = { label = 'Subestacion Costa Oeste', coords = vector3(-1189.44, -1507.88, 4.38) }
    },
    {
        id = 'SUR-LOS-SANTOS',
        name = 'Sur de Los Santos residencial',
        priority = 3,
        economicWeight = 48,
        populationWeight = 96,
        housingBasePrice = 230000,
        capacity = 112,
        baseLoad = 56,
        zones = { 'DAVIS', 'CHAMH', 'RANCHO', 'STRAW', 'SKID', 'STAD' },
        substation = { label = 'Subestacion Davis', coords = vector3(90.33, -1912.18, 20.95) }
    },
    {
        id = 'ESTE-INDUSTRIAL',
        name = 'Este industrial y puerto',
        priority = 1,
        economicWeight = 94,
        populationWeight = 42,
        housingBasePrice = 115000,
        capacity = 146,
        baseLoad = 70,
        zones = { 'CYPRE', 'ELYSIAN', 'TERMINA', 'ZP_ORT', 'ZQ_UAR', 'BANNING', 'EBURO' },
        substation = { label = 'Subestacion Puerto Industrial', coords = vector3(1025.19, -2514.83, 28.30) }
    },
    {
        id = 'ESTE-RESIDENCIAL',
        name = 'Este residencial y Mirror Park',
        priority = 3,
        economicWeight = 58,
        populationWeight = 78,
        housingBasePrice = 410000,
        capacity = 108,
        baseLoad = 50,
        zones = { 'MIRR', 'EAST_V', 'MURRI', 'LMESA', 'HORS' },
        substation = { label = 'Subestacion Mirror Park', coords = vector3(1138.49, -466.71, 66.49) }
    },
    {
        id = 'AEROPUERTO-LOGISTICO',
        name = 'Aeropuerto y logistica',
        priority = 1,
        economicWeight = 90,
        populationWeight = 24,
        housingBasePrice = 140000,
        capacity = 120,
        baseLoad = 62,
        zones = { 'AIRP', 'OCEANA' },
        substation = { label = 'Subestacion Aeropuerto', coords = vector3(-1036.41, -2732.12, 20.16) }
    },
    {
        id = 'SANDY-RURAL',
        name = 'Sandy Shores y desierto',
        priority = 5,
        economicWeight = 38,
        populationWeight = 34,
        housingBasePrice = 125000,
        capacity = 82,
        baseLoad = 31,
        zones = { 'DESRT', 'SANDY', 'HARMO', 'RTRAK', 'SLAB', 'ZANCUDO', 'LAGO', 'ARMYB', 'WINDF', 'SANAND' },
        substation = { label = 'Subestacion Sandy', coords = vector3(1988.05, 3819.73, 32.18) }
    },
    {
        id = 'PALETO-NORTE',
        name = 'Paleto y norte del condado',
        priority = 4,
        economicWeight = 36,
        populationWeight = 48,
        housingBasePrice = 245000,
        capacity = 86,
        baseLoad = 36,
        zones = { 'PALETO', 'PALFOR', 'PALCOV', 'PROCOB', 'NCHU', 'PALHIGH', 'MTCHIL', 'BRADP', 'BRADT', 'CMSW' },
        substation = { label = 'Subestacion Paleto', coords = vector3(-71.26, 6507.22, 31.49) }
    },
    {
        id = 'GRAPESEED-AGRO',
        name = 'Grapeseed, Alamo y zona agricola',
        priority = 4,
        economicWeight = 44,
        populationWeight = 32,
        housingBasePrice = 155000,
        capacity = 84,
        baseLoad = 34,
        zones = { 'GRAPES', 'ALAMO', 'CALAFI', 'CALAFB', 'CANNY', 'CCREAK', 'ELGORL', 'GALFISH', 'MTGORDO', 'TATAMO', 'MTJOSE' },
        substation = { label = 'Subestacion Grapeseed', coords = vector3(1689.77, 4778.54, 41.92) }
    },
    {
        id = 'BANHAM-CHUMASH',
        name = 'Banham, Chumash y Tongva',
        priority = 3,
        economicWeight = 54,
        populationWeight = 26,
        housingBasePrice = 790000,
        capacity = 90,
        baseLoad = 36,
        zones = { 'CHU', 'BHAMCA', 'BANHAMC', 'BAYTRE', 'TONGVAH', 'TONGVAV', 'GREATC' },
        substation = { label = 'Subestacion Chumash', coords = vector3(-3191.24, 1101.39, 20.84) }
    },
    {
        id = 'INFRA-CRITICA',
        name = 'Infraestructura critica y laboratorios',
        priority = 1,
        economicWeight = 86,
        populationWeight = 12,
        housingBasePrice = 90000,
        capacity = 132,
        baseLoad = 58,
        zones = { 'HUMLAB', 'NOOSE', 'JAIL', 'LACT', 'LDAM', 'PALMPOW' },
        substation = { label = 'Subestacion Infraestructura Critica', coords = vector3(2505.15, -383.82, 94.12) }
    }
}

-- Zone aliases/overrides. Use this if your server has custom zone names or if a code differs.
Config.ZoneOverrides = {
    CALAFB = 'GRAPESEED-AGRO',
    BANHAMC = 'BANHAM-CHUMASH',
    LOSPUER = 'COSTA-OESTE'
}
