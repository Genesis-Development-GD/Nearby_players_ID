-- Optional SQL for the electrician job and a repair item.
-- Run only if your database uses the standard jobs/job_grades/items tables.

INSERT INTO jobs (name, label) VALUES
('electrician', 'Servicio Electrico')
ON DUPLICATE KEY UPDATE label = VALUES(label);

INSERT INTO job_grades (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
('electrician', 0, 'trainee', 'Aprendiz', 250, '{}', '{}'),
('electrician', 1, 'technician', 'Tecnico', 400, '{}', '{}'),
('electrician', 2, 'engineer', 'Ingeniero', 650, '{}', '{}'),
('electrician', 3, 'boss', 'Jefe de servicio', 900, '{}', '{}')
ON DUPLICATE KEY UPDATE label = VALUES(label), salary = VALUES(salary);

INSERT INTO items (name, label, weight, rare, can_remove) VALUES
('electric_repairkit', 'Kit electrico', 2, 0, 1)
ON DUPLICATE KEY UPDATE label = VALUES(label);
