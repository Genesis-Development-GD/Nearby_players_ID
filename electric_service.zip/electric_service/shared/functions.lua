ElectricService = ElectricService or {}

local circuitIndex = nil
local zoneIndex = nil

local function upper(value)
    if value == nil then return nil end
    return string.upper(tostring(value))
end

function ElectricService.Debug(message)
    if Config and Config.Debug then
        print(('[%s] %s'):format(Config.ResourceName or 'electric', tostring(message)))
    end
end

function ElectricService.BuildIndexes()
    circuitIndex = {}
    zoneIndex = {}

    for _, circuit in ipairs(Config.Circuits or {}) do
        circuitIndex[circuit.id] = circuit

        for _, zone in ipairs(circuit.zones or {}) do
            zoneIndex[upper(zone)] = circuit.id
        end
    end

    for zone, circuitId in pairs(Config.ZoneOverrides or {}) do
        zoneIndex[upper(zone)] = circuitId
    end
end

local function ensureIndexes()
    if circuitIndex == nil or zoneIndex == nil then
        ElectricService.BuildIndexes()
    end
end

function ElectricService.GetCircuitById(circuitId)
    ensureIndexes()
    return circuitIndex[circuitId]
end

function ElectricService.GetCircuitIdByZone(zoneCode, useFallback)
    ensureIndexes()
    local id = zoneIndex[upper(zoneCode or '')]

    if id then
        return id
    end

    if useFallback == false then
        return nil
    end

    return Config.FallbackCircuit
end

function ElectricService.GetCircuitByZone(zoneCode, useFallback)
    local circuitId = ElectricService.GetCircuitIdByZone(zoneCode, useFallback)
    if not circuitId then return nil end
    return ElectricService.GetCircuitById(circuitId)
end

function ElectricService.GetHousingClassFromPrice(price)
    price = tonumber(price or 0) or 0

    for className, definition in pairs(Config.HousingClasses or {}) do
        local min = tonumber(definition.min or 0) or 0
        local max = tonumber(definition.max or 999999999) or 999999999
        if price >= min and price <= max then
            return className
        end
    end

    return 'economica'
end

function ElectricService.GetCircuitClass(circuit)
    if not circuit then return 'economica' end

    if circuit.class and not Config.UsePriceClassInference then
        return circuit.class
    end

    if circuit.class and circuit.forceClass then
        return circuit.class
    end

    return ElectricService.GetHousingClassFromPrice(circuit.housingBasePrice)
end

function ElectricService.GetClassDefinition(className)
    return (Config.HousingClasses or {})[className or 'economica'] or (Config.HousingClasses or {}).economica or {}
end

function ElectricService.GetImportanceScore(circuit)
    if not circuit then return 0 end

    local economic = tonumber(circuit.economicWeight or 0) or 0
    local population = tonumber(circuit.populationWeight or 0) or 0
    local priority = tonumber(circuit.priority or 5) or 5
    local priorityScore = math.max(0, (6 - priority) * 10)

    return math.floor((economic * 0.45) + (population * 0.35) + priorityScore)
end

function ElectricService.GetStatusLabel(status)
    local labels = {
        online = 'Con servicio',
        offline = 'Sin servicio',
        maintenance = 'Mantenimiento',
        overloaded = 'Sobrecarga'
    }

    return labels[status] or tostring(status or 'desconocido')
end

function ElectricService.GetCircuitLabel(circuit)
    if not circuit then return 'Circuito desconocido' end
    return ('%s (%s)'):format(circuit.name or circuit.id, circuit.id)
end

function ElectricService.FormatMoney(amount)
    amount = tonumber(amount or 0) or 0
    local formatted = tostring(math.floor(amount))
    local k

    while true do
        formatted, k = formatted:gsub('^(-?%d+)(%d%d%d)', '%1.%2')
        if k == 0 then break end
    end

    return ('$%s'):format(formatted)
end

function ElectricService.Round(number, decimals)
    local multiplier = 10 ^ (decimals or 0)
    return math.floor((number * multiplier) + 0.5) / multiplier
end

ElectricService.BuildIndexes()

function ElectricService.GetPropertyTypeLabel(propertyType)
    local billing = Config and Config.Billing or {}
    local labels = billing.propertyTypes or {}
    return labels[propertyType or 'house'] or tostring(propertyType or 'house')
end

function ElectricService.GetDebtCircuitId(ownerIdentifier)
    local billing = Config and Config.Billing or {}
    local debt = billing.debtCircuit or {}
    local prefix = debt.prefix or 'DEBT'
    local safe = tostring(ownerIdentifier or 'unknown'):gsub('[^%w]+', '')
    if #safe > 12 then
        safe = safe:sub(#safe - 11)
    end
    if safe == '' then safe = 'unknown' end
    return ('%s-%s'):format(prefix, safe)
end
