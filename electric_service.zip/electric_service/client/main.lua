local Core = nil
local Grid = { version = 0, circuits = {} }
local CurrentCircuitId = nil
local CurrentPower = nil
local CurrentZone = nil
local BlackoutActive = false
local RepairActive = false
local Blips = {}
local PhoneAppOpen = false
local LatestBillingOverview = nil
local ElectricianAppOpen = false
local LatestElectricianDashboard = nil
local CurrentPropertyId = nil
local PropertyPowerCache = {}
local RepairRouteBlips = {}

local function LoadFramework()
    while Core == nil do
        local ok, object = pcall(function()
            return exports[Config.Framework.resource or 'es_extended']:getSharedObject()
        end)

        if ok and object then
            Core = object
            break
        end

        Wait(500)
    end
end

local function Notify(message)
    if Core and Core.ShowNotification then
        Core.ShowNotification(message)
        return
    end

    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(message)
    EndTextCommandThefeedPostTicker(false, true)
end

local function ShowHelp(message)
    if Core and Core.ShowHelpNotification then
        Core.ShowHelpNotification(message)
        return
    end

    BeginTextCommandDisplayHelp('STRING')
    AddTextComponentSubstringPlayerName(message)
    EndTextCommandDisplayHelp(0, false, true, -1)
end

local function ChatMessage(title, message)
    TriggerEvent('chat:addMessage', {
        color = { 80, 180, 255 },
        multiline = true,
        args = { title, message }
    })
end

local function VectorToTable(coords)
    return { x = coords.x, y = coords.y, z = coords.z }
end

local function GetZoneLabel(zoneCode)
    if not zoneCode then return 'Desconocida' end
    local label = GetLabelText(zoneCode)
    if not label or label == 'NULL' then return zoneCode end
    return label
end

local function GetCurrentCircuitState()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local zoneCode = GetNameOfZone(coords.x, coords.y, coords.z)
    local circuitId = ElectricService.GetCircuitIdByZone(zoneCode, true)
    local state = Grid.circuits and Grid.circuits[circuitId] or nil

    if state then
        return state, zoneCode
    end

    local circuit = ElectricService.GetCircuitById(circuitId)
    if not circuit then return nil, zoneCode end

    local className = ElectricService.GetCircuitClass(circuit)
    local classDef = ElectricService.GetClassDefinition(className)

    return {
        id = circuit.id,
        name = circuit.name,
        class = className,
        classLabel = classDef.label or className,
        status = 'online',
        statusLabel = ElectricService.GetStatusLabel('online'),
        powered = true,
        health = 100,
        load = circuit.baseLoad or 0,
        capacity = circuit.capacity or 100,
        housingBasePrice = circuit.housingBasePrice or 0,
        priority = circuit.priority or 5,
        economicWeight = circuit.economicWeight or 0,
        populationWeight = circuit.populationWeight or 0
    }, zoneCode
end

local function ClientHasPower(circuitId)
    if circuitId then
        local state = Grid.circuits and Grid.circuits[circuitId] or nil
        if not state then return true end
        return state.powered ~= false
    end

    local state = GetCurrentCircuitState()
    if not state then return true end
    return state.powered ~= false
end

local function ApplyLocalBlackout(enabled)
    if not Config.Visual.localBlackout then return end
    if BlackoutActive == enabled then return end

    BlackoutActive = enabled
    SetArtificialLightsState(enabled)
end

local function GetBlipColor(status)
    if status == 'offline' then return Config.Blips.substation.colorOffline end
    if status == 'maintenance' then return Config.Blips.substation.colorMaintenance end
    return Config.Blips.substation.colorOnline
end

local function RemoveBlips()
    for _, blip in pairs(Blips) do
        if DoesBlipExist(blip) then
            RemoveBlip(blip)
        end
    end

    Blips = {}
end

local function UpdateBlips()
    if not Config.Visual.showSubstationBlips then return end

    RemoveBlips()

    for _, circuit in ipairs(Config.Circuits or {}) do
        if circuit.substation and circuit.substation.coords then
            local state = Grid.circuits and Grid.circuits[circuit.id] or nil
            local status = state and state.status or 'online'

            if not Config.Visual.showOnlyOfflineBlips or status ~= 'online' then
                local coords = circuit.substation.coords
                local blip = AddBlipForCoord(coords.x, coords.y, coords.z)

                SetBlipSprite(blip, Config.Blips.substation.sprite)
                SetBlipScale(blip, Config.Blips.substation.scale)
                SetBlipColour(blip, GetBlipColor(status))
                SetBlipAsShortRange(blip, Config.Blips.substation.shortRange)

                BeginTextCommandSetBlipName('STRING')
                AddTextComponentString(('Subestacion - %s'):format(circuit.id))
                EndTextCommandSetBlipName(blip)

                Blips[circuit.id] = blip
            end
        end
    end
end


local function ClearRepairRouteBlips()
    for _, blip in ipairs(RepairRouteBlips) do
        if DoesBlipExist(blip) then
            SetBlipRoute(blip, false)
            RemoveBlip(blip)
        end
    end

    RepairRouteBlips = {}
end

local function CreateRepairRoute(circuits)
    ClearRepairRouteBlips()

    circuits = circuits or {}
    if #circuits <= 0 then
        Notify('No hay circuitos apagados por averia para marcar.')
        return false
    end

    local routeConfig = (Config.RepairApp and Config.RepairApp.routeBlip) or {}
    local added = 0

    for index, circuit in ipairs(circuits) do
        local substation = circuit.substation or {}
        local x = tonumber(substation.x)
        local y = tonumber(substation.y)
        local z = tonumber(substation.z)

        if x and y and z then
            local blip = AddBlipForCoord(x, y, z)
            SetBlipSprite(blip, routeConfig.sprite or Config.Blips.substation.sprite or 354)
            SetBlipScale(blip, routeConfig.scale or 0.85)
            SetBlipColour(blip, routeConfig.color or Config.Blips.substation.colorOffline or 1)
            SetBlipAsShortRange(blip, routeConfig.shortRange == true)

            BeginTextCommandSetBlipName('STRING')
            AddTextComponentString(('Reparar - %s'):format(circuit.id or 'Circuito'))
            EndTextCommandSetBlipName(blip)

            if index == 1 then
                SetNewWaypoint(x, y)
                SetBlipRoute(blip, true)
                SetBlipRouteColour(blip, routeConfig.routeColor or routeConfig.color or 5)
            end

            RepairRouteBlips[#RepairRouteBlips + 1] = blip
            added = added + 1
        end
    end

    if added <= 0 then
        Notify('No se pudieron marcar subestaciones validas.')
        return false
    end

    Notify(('Ruta tecnica creada con %s subestacion(es).'):format(added))
    return true
end

local function RequestGrid()
    if not Core then return end

    Core.TriggerServerCallback('electric_service:server:getGrid', function(data)
        if data and data.circuits then
            Grid = data
            UpdateBlips()
        end
    end)
end


local function SendPhoneAppData(data)
    LatestBillingOverview = data or LatestBillingOverview
    SendNUIMessage({
        action = 'billing:update',
        data = LatestBillingOverview,
        title = (Config.Billing and Config.Billing.app and Config.Billing.app.title) or 'Servicio electrico'
    })
end

local function RequestBillingOverview()
    if not Core then return end

    Core.TriggerServerCallback('electric_service:server:getBillingOverview', function(data)
        LatestBillingOverview = data
        if PhoneAppOpen then
            SendPhoneAppData(data)
        end
    end)
end

local function SendElectricianAppData(data)
    LatestElectricianDashboard = data or LatestElectricianDashboard
    SendNUIMessage({
        action = 'tech:update',
        data = LatestElectricianDashboard,
        title = (Config.RepairApp and Config.RepairApp.title) or 'Panel tecnico electrico'
    })
end

local function RequestElectricianDashboard()
    if not Core then return end

    Core.TriggerServerCallback('electric_service:server:getElectricianDashboard', function(result)
        if not result or not result.ok then
            if result and result.message then Notify(result.message) end
            if ElectricianAppOpen then SendElectricianAppData(result or { ok = false, circuits = {} }) end
            return
        end

        LatestElectricianDashboard = result
        if ElectricianAppOpen then
            SendElectricianAppData(result)
        end
    end)
end

local function OpenPhoneApp()
    if not Core then
        Notify('El framework no esta listo todavia.')
        return
    end

    PhoneAppOpen = true
    ElectricianAppOpen = false
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'app:open',
        title = (Config.Billing and Config.Billing.app and Config.Billing.app.title) or 'Servicio electrico'
    })
    RequestBillingOverview()
end

local function OpenElectricianApp()
    if not Core then
        Notify('El framework no esta listo todavia.')
        return
    end

    Core.TriggerServerCallback('electric_service:server:getElectricianDashboard', function(result)
        if not result or not result.ok then
            Notify((result and result.message) or 'No puedes abrir el panel tecnico.')
            return
        end

        PhoneAppOpen = false
        ElectricianAppOpen = true
        LatestElectricianDashboard = result
        SetNuiFocus(true, true)
        SendNUIMessage({
            action = 'tech:open',
            title = result.title or (Config.RepairApp and Config.RepairApp.title) or 'Panel tecnico electrico',
            data = result
        })
    end)
end

local function ClosePhoneApp()
    PhoneAppOpen = false
    ElectricianAppOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'app:close' })
end

local LastPropertyPowerRequest = 0

local function RequestPropertyPower(propertyId)
    if not Core or not propertyId then return end

    Core.TriggerServerCallback('electric_service:server:getPropertyPower', function(result)
        if result and result.ok then
            PropertyPowerCache[propertyId] = result
        end
    end, propertyId)
end

local function SetCurrentProperty(propertyId)
    CurrentPropertyId = propertyId

    if propertyId then
        RequestPropertyPower(propertyId)
    else
        PropertyPowerCache = {}
    end
end

local function GetDebtBlockedForCurrentProperty()
    if not CurrentPropertyId then return false end
    local cached = PropertyPowerCache[CurrentPropertyId]
    if not cached then return false end
    return cached.debtBlocked == true
end

RegisterNUICallback('close', function(_, cb)
    ClosePhoneApp()
    cb({ ok = true })
end)

RegisterNUICallback('refresh', function(_, cb)
    if not Core then
        cb({ ok = false, message = 'Framework no listo.' })
        return
    end

    Core.TriggerServerCallback('electric_service:server:getBillingOverview', function(data)
        LatestBillingOverview = data
        SendPhoneAppData(data)
        cb({ ok = true, data = data })
    end)
end)

RegisterNUICallback('payPending', function(_, cb)
    if not Core then
        cb({ ok = false, message = 'Framework no listo.' })
        return
    end

    Core.TriggerServerCallback('electric_service:server:payPendingBills', function(result)
        if result and result.message then Notify(result.message) end
        if result and result.overview then SendPhoneAppData(result.overview) end
        if CurrentPropertyId then RequestPropertyPower(CurrentPropertyId) end
        cb(result or { ok = false })
    end)
end)

RegisterNUICallback('setAutoPay', function(data, cb)
    if not Core then
        cb({ ok = false, message = 'Framework no listo.' })
        return
    end

    Core.TriggerServerCallback('electric_service:server:setAutoPay', function(result)
        if result and result.message then Notify(result.message) end
        if result and result.overview then SendPhoneAppData(result.overview) end
        cb(result or { ok = false })
    end, data and data.enabled == true)
end)

RegisterNUICallback('refreshTech', function(_, cb)
    if not Core then
        cb({ ok = false, message = 'Framework no listo.' })
        return
    end

    Core.TriggerServerCallback('electric_service:server:getElectricianDashboard', function(result)
        if result and result.message and not result.ok then Notify(result.message) end
        LatestElectricianDashboard = result
        SendElectricianAppData(result or { ok = false, circuits = {} })
        cb(result or { ok = false })
    end)
end)

RegisterNUICallback('routeRepairs', function(_, cb)
    local circuits = (LatestElectricianDashboard and LatestElectricianDashboard.circuits) or {}
    local ok = CreateRepairRoute(circuits)
    cb({ ok = ok })
end)

RegisterNUICallback('routeSingleRepair', function(data, cb)
    local circuitId = data and data.circuitId
    local selected = nil

    for _, circuit in ipairs((LatestElectricianDashboard and LatestElectricianDashboard.circuits) or {}) do
        if circuit.id == circuitId then
            selected = circuit
            break
        end
    end

    local ok = false
    if selected then
        ok = CreateRepairRoute({ selected })
    else
        Notify('Circuito no encontrado en el panel tecnico.')
    end

    cb({ ok = ok })
end)

RegisterNUICallback('clearRepairRoute', function(_, cb)
    ClearRepairRouteBlips()
    Notify('Ruta tecnica eliminada.')
    cb({ ok = true })
end)

local function GetMarkerColor(status)
    if status == 'offline' then return Config.Marker.colorOffline end
    if status == 'maintenance' then return Config.Marker.colorMaintenance end
    return Config.Marker.colorOnline
end

local function DrawProgressText(text)
    SetTextFont(4)
    SetTextProportional(0)
    SetTextScale(0.36, 0.36)
    SetTextColour(255, 255, 255, 230)
    SetTextCentre(true)
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.5, 0.88)
end

local function StartRepair(circuitId)
    if RepairActive then
        Notify('Ya estas reparando un circuito.')
        return
    end

    if not Core then
        Notify('El framework no esta listo todavia.')
        return
    end

    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)

    Core.TriggerServerCallback('electric_service:server:canRepair', function(result)
        if not result or not result.ok then
            Notify((result and result.message) or 'No puedes reparar este circuito.')
            return
        end

        CreateThread(function()
            RepairActive = true

            local circuit = ElectricService.GetCircuitById(circuitId)
            local duration = tonumber(result.duration or Config.Repair.durationMs) or Config.Repair.durationMs
            local startTime = GetGameTimer()
            local cancelled = false

            FreezeEntityPosition(ped, true)
            TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_WELDING', 0, true)

            while GetGameTimer() - startTime < duration do
                Wait(0)

                local elapsed = GetGameTimer() - startTime
                local percent = math.floor((elapsed / duration) * 100)
                DrawProgressText(('Reparando %s - %s%% | Pulsa X para cancelar'):format(circuitId, percent))

                DisableControlAction(0, 38, true)

                if IsControlJustPressed(0, 73) or IsEntityDead(ped) then
                    cancelled = true
                    break
                end

                if circuit and circuit.substation and circuit.substation.coords then
                    local playerCoords = GetEntityCoords(ped)
                    local dist = #(playerCoords - circuit.substation.coords)
                    if dist > (Config.Repair.maxDistance + 2.0) then
                        cancelled = true
                        break
                    end
                end
            end

            ClearPedTasks(ped)
            FreezeEntityPosition(ped, false)
            RepairActive = false

            if cancelled then
                Notify('Reparacion cancelada.')
                return
            end

            TriggerServerEvent('electric_service:server:finishRepair', circuitId)
        end)
    end, circuitId, VectorToTable(coords))
end

RegisterNetEvent('electric_service:client:syncGrid', function(data)
    if data and data.circuits then
        Grid = data
        UpdateBlips()

        if ElectricianAppOpen then
            RequestElectricianDashboard()
        end
    end
end)

RegisterNetEvent('electric_service:client:notify', function(message)
    Notify(message)
end)


RegisterNetEvent('electric_service:client:billingChanged', function(data)
    LatestBillingOverview = data
    if PhoneAppOpen then
        SendPhoneAppData(data)
    end

    if CurrentPropertyId and data and data.properties then
        for _, property in ipairs(data.properties) do
            if property.id == CurrentPropertyId then
                PropertyPowerCache[CurrentPropertyId] = {
                    ok = true,
                    powered = property.powered,
                    zoneCircuitPowered = property.zoneCircuitPowered,
                    debtBlocked = property.debtBlocked,
                    reason = property.powerReason,
                    property = property
                }
                break
            end
        end
    end
end)

RegisterNetEvent('electric_service:client:openPhoneApp', function()
    OpenPhoneApp()
end)

RegisterNetEvent('electric_service:client:openElectricianApp', function()
    OpenElectricianApp()
end)

RegisterNetEvent('electric_service:client:enterProperty', function(propertyId)
    SetCurrentProperty(propertyId)
end)

RegisterNetEvent('electric_service:client:exitProperty', function()
    SetCurrentProperty(nil)
end)

RegisterNetEvent('electric_service:client:circuitChanged', function(data)
    if not data then return end

    if data.status == 'offline' then
        Notify(('Corte electrico en %s. Motivo: %s'):format(data.name or data.id, data.reason or 'No indicado'))
    elseif data.status == 'online' then
        Notify(('Servicio restaurado en %s.'):format(data.name or data.id))
    elseif data.status == 'maintenance' then
        Notify(('Mantenimiento electrico en %s.'):format(data.name or data.id))
    end
end)

CreateThread(function()
    LoadFramework()
    Wait(1000)
    RequestGrid()
    RequestBillingOverview()
end)

AddEventHandler('playerSpawned', function()
    Wait(1000)
    RequestGrid()
    RequestBillingOverview()
end)

CreateThread(function()
    while true do
        Wait((Config.Visual.updateSeconds or 3) * 1000)

        local state, zoneCode = GetCurrentCircuitState()
        local zonePowered = not state or state.powered ~= false
        local circuitId = state and state.id or nil

        if CurrentPropertyId and GetGameTimer() - LastPropertyPowerRequest > 10000 then
            LastPropertyPowerRequest = GetGameTimer()
            RequestPropertyPower(CurrentPropertyId)
        end

        local powered = zonePowered and not GetDebtBlockedForCurrentProperty()

        if circuitId and Config.Visual.notifyWhenCircuitChanges and CurrentCircuitId and CurrentCircuitId ~= circuitId then
            Notify(('Entraste al circuito %s (%s).'):format(state.name or circuitId, state.classLabel or state.class or 'sin clase'))
        end

        if Config.Visual.notifyWhenPowerChanges and CurrentPower ~= nil and CurrentPower ~= powered then
            if powered then
                Notify('La energia electrica ha vuelto en esta zona.')
            else
                Notify('Esta zona esta sin servicio electrico.')
            end
        end

        CurrentCircuitId = circuitId
        CurrentPower = powered
        CurrentZone = zoneCode

        ApplyLocalBlackout(not powered)
    end
end)

CreateThread(function()
    while true do
        local sleep = 1000

        if Config.Marker.enabled and Config.Repair.enabled then
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)

            for _, circuit in ipairs(Config.Circuits or {}) do
                if circuit.substation and circuit.substation.coords then
                    local subCoords = circuit.substation.coords
                    local dist = #(coords - subCoords)

                    if dist < Config.Marker.drawDistance then
                        sleep = 0
                        local state = Grid.circuits and Grid.circuits[circuit.id] or nil
                        local status = state and state.status or 'online'
                        local health = state and state.health or 100
                        local color = GetMarkerColor(status)

                        DrawMarker(
                            Config.Marker.type,
                            subCoords.x, subCoords.y, subCoords.z - 1.0,
                            0.0, 0.0, 0.0,
                            0.0, 0.0, 0.0,
                            Config.Marker.size.x, Config.Marker.size.y, Config.Marker.size.z,
                            color.r, color.g, color.b, color.a,
                            false, true, 2, false, nil, nil, false
                        )

                        if dist <= Config.Marker.interactDistance then
                            if status ~= 'online' or health < 100 then
                                ShowHelp(('Pulsa ~INPUT_CONTEXT~ para reparar %s'):format(circuit.id))
                                if IsControlJustReleased(0, 38) then
                                    StartRepair(circuit.id)
                                end
                            else
                                ShowHelp(('Subestacion operativa: %s'):format(circuit.id))
                            end
                        end
                    end
                end
            end
        end

        Wait(sleep)
    end
end)

RegisterCommand(Config.Commands.phoneApp, function()
    if Config.Billing and Config.Billing.app and Config.Billing.app.commandEnabled == false then return end
    OpenPhoneApp()
end, false)

RegisterCommand(Config.Commands.electricianApp, function()
    if Config.RepairApp and Config.RepairApp.commandEnabled == false then return end
    OpenElectricianApp()
end, false)

RegisterCommand(Config.Commands.clearRepairRoute, function()
    ClearRepairRouteBlips()
    Notify('Ruta tecnica eliminada.')
end, false)

RegisterCommand(Config.Commands.current, function()
    local state, zoneCode = GetCurrentCircuitState()
    if not state then
        ChatMessage('Electricidad', 'No se pudo detectar el circuito actual.')
        return
    end

    local price = ElectricService.FormatMoney(state.housingBasePrice or 0)
    local status = state.statusLabel or ElectricService.GetStatusLabel(state.status)
    local zoneLabel = GetZoneLabel(zoneCode)
    local powerText = state.powered and 'SI' or 'NO'

    ChatMessage('Electricidad', ('Zona: %s [%s]\nCircuito: %s (%s)\nClase: %s | Precio vivienda base: %s\nServicio: %s | Energia: %s\nCarga: %s/%s | Salud: %s%%'):format(
        zoneLabel,
        zoneCode or 'N/A',
        state.name or 'N/A',
        state.id or 'N/A',
        state.classLabel or state.class or 'N/A',
        price,
        status,
        powerText,
        tostring(state.load or 0),
        tostring(state.capacity or 0),
        tostring(state.health or 0)
    ))
end, false)

RegisterCommand(Config.Commands.grid, function()
    ChatMessage('Red electrica', 'Estado de circuitos principales:')

    for _, circuit in ipairs(Config.Circuits or {}) do
        local state = Grid.circuits and Grid.circuits[circuit.id] or nil
        local status = state and (state.statusLabel or ElectricService.GetStatusLabel(state.status)) or 'Con servicio'
        local className = state and state.classLabel or ElectricService.GetClassDefinition(ElectricService.GetCircuitClass(circuit)).label
        local powered = (not state or state.powered ~= false) and 'ON' or 'OFF'
        local load = state and state.load or circuit.baseLoad or 0
        local capacity = state and state.capacity or circuit.capacity or 100

        ChatMessage('Red electrica', ('%s | %s | %s | %s | carga %s/%s'):format(circuit.id, status, powered, className, load, capacity))
    end
end, false)

RegisterCommand(Config.Commands.substation, function(_, args)
    local circuitId = args[1]

    if not circuitId then
        local state = GetCurrentCircuitState()
        circuitId = state and state.id or nil
    end

    local circuit = circuitId and ElectricService.GetCircuitById(circuitId) or nil
    if not circuit or not circuit.substation or not circuit.substation.coords then
        Notify('No se encontro esa subestacion.')
        return
    end

    local coords = circuit.substation.coords
    SetNewWaypoint(coords.x, coords.y)
    Notify(('GPS marcado: %s'):format(circuit.substation.label or circuit.id))
end, false)

exports('HasPower', function(circuitId)
    if not circuitId and CurrentPropertyId then
        return ClientHasPower(nil) and not GetDebtBlockedForCurrentProperty()
    end

    return ClientHasPower(circuitId)
end)

exports('OpenPhoneApp', function()
    OpenPhoneApp()
end)

exports('OpenElectricianApp', function()
    OpenElectricianApp()
end)

exports('ClearRepairRoute', function()
    ClearRepairRouteBlips()
end)

exports('EnterProperty', function(propertyId)
    SetCurrentProperty(propertyId)
end)

exports('ExitProperty', function()
    SetCurrentProperty(nil)
end)

exports('GetCurrentPropertyId', function()
    return CurrentPropertyId
end)

exports('GetCurrentPropertyPower', function()
    if not CurrentPropertyId then return nil end
    return PropertyPowerCache[CurrentPropertyId]
end)

exports('GetCurrentCircuit', function()
    local state = GetCurrentCircuitState()
    return state
end)

exports('GetCircuitState', function(circuitId)
    return Grid.circuits and Grid.circuits[circuitId] or nil
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    ApplyLocalBlackout(false)
    RemoveBlips()
    ClearRepairRouteBlips()
end)
