fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'OpenAI'
description 'Electric service: circuits, billing, outages, repair apps and technician routes'
version '1.2.0'

dependency 'es_extended'

shared_scripts {
    'config.lua',
    'shared/functions.lua'
}

client_scripts {
    'client/main.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js'
}

server_scripts {
    'server/main.lua'
}
