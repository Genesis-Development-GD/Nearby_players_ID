ELECTRIC SERVICE - ENGLISH README
=================================

Overview
--------
Electric Service simulates an electrical grid for the map. The map is divided into zone circuits with different priority, economic weight, population weight and social class. It also includes monthly property billing, debt-based property power cuts and repair gameplay for electrician players.

Main power rule:
Property has power = zone circuit has power + property has no overdue debt.

This means the virtual debt circuit never changes the status of the real zone circuits. If a zone circuit is offline, the property has no power even if the owner paid. If the zone circuit is online but the property has overdue debt, only that property loses power.

Main features
-------------
1. Zone electrical circuits
   Splits the map into configurable circuits. Each circuit has a substation, priority, load, health, social class and GTA zone codes.

2. Social classes based on housing prices
   Zones can be classified as economic, low class, middle class or high class using the configured housing base price.

3. Failure outages
   The server can create failures from overload, circuit health or random events. Failed circuits require repair.

4. Admin outages and restoration
   Administrators can cut, restore or set maintenance on zone circuits with commands.

5. Substation markers
   Each circuit has a substation. Markers help electricians find and repair offline circuits.

6. Electrician job gameplay
   Players with the electrician job can repair offline or damaged substations. The server validates job, distance, optional item and circuit status.

7. Player billing phone app
   Players can open a simple phone app to see their properties, days left, pending amount, payment button and auto-pay toggle.

8. Monthly property billing
   Each house or business can have a monthly fee based on social class, circuit, GTA zone or server override.

9. Property debt power cuts
   If an invoice expires, the property power is blocked through a virtual debt circuit. This circuit is informational and does not modify the zone grid.

10. Auto-pay
    Players can enable a toggle to try automatic payment on day 1 of each in-game month.

11. Electrician phone app
    Electricians have a separate app where they can see zone circuits offline due to failures. The app includes a repair route button.

12. Repair route on minimap
    The electrician app marks the first substation as the GPS route and adds minimap markers for every failed substation.

13. JSON persistence
    Grid and billing state are saved to JSON files for easy installation and testing.

14. Integration exports
    Other resources can check circuit or property power, register properties, open apps or pay bills through code.

Roles and usage
---------------

PLAYER / CIVILIAN
~~~~~~~~~~~~~~~~~
Can do:
- Check the current zone electrical status.
- Check the main grid summary.
- Open the billing app.
- Pay pending invoices.
- Enable or disable auto-pay.
- See whether their properties have power or are cut due to debt.

Commands:
/circuito
Shows current zone, circuit, social class, housing base price, load, health and power state.

/redluz
Shows a summary of all main zone circuits.

/subestacion
Marks the current circuit substation on GPS.

/subestacion <circuit>
Marks a specific circuit substation on GPS.
Example: /subestacion LS-CENTRO

/luzapp
Opens the player billing app.

Billing app:
- Shows total pending amount.
- Shows days left to pay.
- Allows paying the pending invoice.
- Allows enabling auto-pay on day 1.
- Lists registered houses and businesses.
- Shows whether each property has power.

ELECTRICIAN
~~~~~~~~~~~
Can do:
- See failed zone circuits through a technician app.
- Create a repair route to failed substations.
- Repair circuits from the substation.
- Receive repair payment if configured.

Requirement:
- Must have a job configured in Config.ElectricianJobs. Default: electrician.

Commands:
/luztecnico
Opens the electrician app. It only shows real zone circuits that are offline due to failure and require repair.

/luzruta_clear
Removes the technician route markers created by the app.

Electrician app usage:
- Open /luztecnico.
- Review the failed circuit list.
- Press "Marcar ruta de reparacion" to create route and markers.
- Go to the marked substation.
- Press E on the substation marker to repair.

Repair flow:
- The server validates the player is an electrician.
- The server validates distance to the substation.
- An item can be required through Config.Repair.requiredItem.
- When repair is completed, the circuit goes online.

ADMINISTRATOR
~~~~~~~~~~~~~
Can do:
- Create manual outages.
- Restore circuits.
- Enable or disable maintenance.
- Review overall grid state.
- Register player properties.
- Remove properties from the electrical system.
- Review player invoices and debt.

Permission:
Recommended ACE:
add_ace group.admin electric_service.admin allow

Commands:
/corte <circuit|zone> [minutes] [reason]
Turns off a zone circuit. By default, it requires repair.
Example: /corte LS-CENTRO 30 Transformer failure

/restaurar <circuit|zone>
Restores a zone circuit.
Example: /restaurar LS-CENTRO

/mantenimiento <circuit|zone> <on|off> [minutes] [reason]
Enables or disables circuit maintenance.
Example: /mantenimiento COSTA-OESTE on 20 Preventive check
Example: /mantenimiento COSTA-OESTE off

/electricidad_estado
Shows the general status of all circuits.

/electricidad_prop_add <playerId> <house|business> <propertyId> <gtaZone> [name]
Registers a house or business for electrical billing.
Example: /electricidad_prop_add 12 house apt_001 ALTA Downtown Apartment

/electricidad_prop_remove <propertyId>
Removes a property from the electrical system.
Example: /electricidad_prop_remove apt_001

/electricidad_prop_estado <propertyId>
Shows electrical information for a property.
Example: /electricidad_prop_estado apt_001

/electricidad_facturas <playerId|identifier>
Shows player debt, auto-pay and registered properties.
Example: /electricidad_facturas 12

DEVELOPER / INTEGRATOR
~~~~~~~~~~~~~~~~~~~~~~
Can do:
- Integrate housing, businesses, interiors, phones or stores.
- Check whether a zone or property has power.
- Register properties from another resource.
- Open the billing app or electrician app from a custom phone.

Useful client events:
TriggerEvent('electric_service:client:openPhoneApp')
Opens the billing app.

TriggerEvent('electric_service:client:openElectricianApp')
Opens the electrician app for electrician players.

TriggerEvent('electric_service:client:enterProperty', 'apt_001')
Marks the current property. This lets the local blackout effect respect property debt.

TriggerEvent('electric_service:client:exitProperty')
Clears the current property.

Client exports:
exports['electric_service']:HasPower()
Returns whether the player has power in the current zone or current property.

exports['electric_service']:OpenPhoneApp()
Opens the billing app.

exports['electric_service']:OpenElectricianApp()
Opens the electrician app.

exports['electric_service']:ClearRepairRoute()
Clears technician route markers.

exports['electric_service']:EnterProperty('apt_001')
Marks the current property.

exports['electric_service']:ExitProperty()
Clears the current property.

Server exports:
exports['electric_service']:IsCircuitPowered('LS-CENTRO')
Checks if a zone circuit has power.

exports['electric_service']:SetCircuitOffline('LS-CENTRO', 15, 'External failure', true)
Turns a circuit offline through code.

exports['electric_service']:SetCircuitOnline('LS-CENTRO', 'Restored')
Restores a circuit through code.

exports['electric_service']:RegisterProperty({ id = 'apt_001', label = 'Apartment 001', owner = 'license:xxxxxxxx', type = 'house', zoneCode = 'ALTA' })
Registers a property for billing.

exports['electric_service']:IsPropertyPowered('apt_001')
Checks if a property has power based on zone circuit state and debt state.

exports['electric_service']:GetRepairOutages()
Returns zone circuits that are offline due to failure and pending repair.

Important configuration
-----------------------
Config.Circuits
Defines circuits, GTA zones, substations, priority, load, class and housing base price.

Config.HousingClasses
Defines price ranges for economic, low, middle and high class zones.

Config.Billing.feesByClass
Defines fees by social class and property type.

Config.Billing.feesByCircuit
Allows special fees by circuit.

Config.Billing.feesByZone
Allows special fees by GTA zone.

Config.Billing.invoice.deadlineDays
Defines the monthly payment deadline in in-game days.

Config.Billing.debtCircuit
Configures the virtual debt circuit. It does not affect zone circuits.

Config.Repair
Configures repair time, required item, payment and maximum distance.

Config.RepairApp
Configures the electrician app, repair route and repair markers.

Basic installation
------------------
1. Copy the electric_service folder into resources/[local]/electric_service.
2. Make sure the base framework starts before this resource.
3. Add this to server.cfg:

ensure es_extended
ensure electric_service

4. Optionally run INSTALL.sql to create the job and repair item.
5. Adjust config.lua to your server economy and housing system.

Final notes
-----------
- Debt cuts are per property, not per zone.
- Failure outages are per zone circuit.
- The electrician app only lists real zone circuits that are offline due to failure.
- The virtual debt circuit is not repairable and is not part of the zone grid.
