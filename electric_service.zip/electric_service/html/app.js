const app = document.getElementById('app');
const title = document.getElementById('title');
const billingScreen = document.getElementById('billingScreen');
const techScreen = document.getElementById('techScreen');

const totalDue = document.getElementById('totalDue');
const daysLeft = document.getElementById('daysLeft');
const payButton = document.getElementById('pay');
const autoPay = document.getElementById('autoPay');
const debtCircuit = document.getElementById('debtCircuit');
const propertiesBox = document.getElementById('properties');

const techCount = document.getElementById('techCount');
const techStatus = document.getElementById('techStatus');
const techCircuits = document.getElementById('techCircuits');

let billingState = null;
let techState = null;
let currentMode = 'billing';
let suppressToggle = false;

function resourceName() {
    return typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'electric_service';
}

function post(name, data = {}) {
    return fetch(`https://${resourceName()}/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(data)
    }).then(response => response.json()).catch(() => ({}));
}

function money(value) {
    value = Number(value || 0);
    return `$${Math.floor(value).toLocaleString('de-DE')}`;
}

function showMode(mode) {
    currentMode = mode;
    billingScreen.classList.toggle('hidden', mode !== 'billing');
    techScreen.classList.toggle('hidden', mode !== 'tech');
}

function renderProperties(properties) {
    propertiesBox.innerHTML = '';

    if (!properties || properties.length === 0) {
        propertiesBox.innerHTML = '<div class="property"><div class="muted">No hay propiedades registradas.</div></div>';
        return;
    }

    properties.forEach(property => {
        const card = document.createElement('div');
        card.className = 'property';

        const powerClass = property.powered ? 'on' : 'off';
        const powerText = property.powered ? 'Con luz' : 'Sin luz';
        const pendingText = Number(property.balance || 0) > 0 ? money(property.balance) : 'Pagada';
        const dueText = Number(property.balance || 0) > 0
            ? `${property.daysLeft || 0} dias para pagar`
            : `Proxima cuota en ${property.daysLeft || 0} dias`;

        card.innerHTML = `
            <div class="property-title">
                <span>${property.label || property.id}</span>
                <span class="badge ${powerClass}">${powerText}</span>
            </div>
            <div class="property-grid">
                <span>Tipo: ${property.typeLabel || property.type}</span>
                <span>Clase: ${property.classLabel || property.class}</span>
                <span>Cuota: ${money(property.monthlyFee)}</span>
                <span>Pendiente: ${pendingText}</span>
                <span>Circuito: ${property.circuitId || 'N/A'}</span>
                <span>${dueText}</span>
            </div>
        `;
        propertiesBox.appendChild(card);
    });
}

function renderBilling(data) {
    billingState = data || {};
    totalDue.textContent = billingState.formattedTotalDue || money(billingState.totalDue || 0);

    if (Number(billingState.totalDue || 0) > 0) {
        daysLeft.textContent = `${billingState.daysLeft || 0} dias restantes para pagar`;
    } else {
        daysLeft.textContent = `Sin factura pendiente. Proxima cuota en ${billingState.daysLeft || 0} dias`;
    }

    payButton.disabled = Number(billingState.totalDue || 0) <= 0;

    suppressToggle = true;
    autoPay.checked = billingState.autoPay === true;
    suppressToggle = false;

    const dc = billingState.debtCircuit || {};
    if (billingState.hasDebt) {
        debtCircuit.textContent = `${dc.id || 'DEBT'} - ${dc.status || 'offline'} - ${money(dc.debtAmount || billingState.totalDue || 0)}`;
    } else {
        debtCircuit.textContent = `${dc.id || 'DEBT'} - online`;
    }

    renderProperties(billingState.properties || []);
}

function renderTechCircuits(circuits) {
    techCircuits.innerHTML = '';

    if (!circuits || circuits.length === 0) {
        techCircuits.innerHTML = '<div class="property"><div class="muted">No hay circuitos apagados por averia.</div></div>';
        return;
    }

    circuits.forEach(circuit => {
        const card = document.createElement('div');
        card.className = 'property';
        const substation = circuit.substation || {};
        const reason = circuit.reason && circuit.reason.length > 0 ? circuit.reason : 'Averia pendiente';

        card.innerHTML = `
            <div class="property-title">
                <span>${circuit.id || 'Circuito'}</span>
                <span class="badge off">Averia</span>
            </div>
            <div class="property-grid single">
                <span>${circuit.name || 'Circuito sin nombre'}</span>
                <span>Prioridad: ${circuit.priority || 'N/A'}</span>
                <span>Carga: ${circuit.load || 0}/${circuit.capacity || 0}</span>
                <span>Salud: ${circuit.health || 0}%</span>
                <span>Subestacion: ${substation.label || circuit.id || 'N/A'}</span>
                <span>Motivo: ${reason}</span>
            </div>
            <button class="secondary card-button" data-circuit-id="${circuit.id || ''}">Marcar esta estacion</button>
        `;

        techCircuits.appendChild(card);
    });

    techCircuits.querySelectorAll('[data-circuit-id]').forEach(button => {
        button.addEventListener('click', () => {
            const circuitId = button.getAttribute('data-circuit-id');
            post('routeSingleRepair', { circuitId });
        });
    });
}

function renderTech(data) {
    techState = data || { circuits: [] };
    const circuits = techState.circuits || [];
    const count = Number(techState.count != null ? techState.count : circuits.length);

    techCount.textContent = String(count);
    techStatus.textContent = count > 0
        ? `${count} circuito(s) requieren reparacion. Pulsa el boton para crear ruta.`
        : 'Sin averias activas en circuitos de zona.';

    document.getElementById('routeAll').disabled = count <= 0;
    renderTechCircuits(circuits);
}

window.addEventListener('message', event => {
    const payload = event.data || {};

    if (payload.action === 'app:open') {
        title.textContent = payload.title || 'Servicio electrico';
        showMode('billing');
        app.classList.remove('hidden');
        post('refresh');
    }

    if (payload.action === 'tech:open') {
        title.textContent = payload.title || 'Panel tecnico electrico';
        showMode('tech');
        app.classList.remove('hidden');
        renderTech(payload.data || {});
    }

    if (payload.action === 'app:close') {
        app.classList.add('hidden');
    }

    if (payload.action === 'billing:update') {
        if (currentMode === 'billing') {
            title.textContent = payload.title || 'Servicio electrico';
        }
        renderBilling(payload.data || {});
    }

    if (payload.action === 'tech:update') {
        if (currentMode === 'tech') {
            title.textContent = payload.title || 'Panel tecnico electrico';
        }
        renderTech(payload.data || {});
    }
});

document.getElementById('close').addEventListener('click', () => post('close'));
document.getElementById('refresh').addEventListener('click', () => post('refresh'));
payButton.addEventListener('click', () => post('payPending'));
autoPay.addEventListener('change', () => {
    if (suppressToggle) return;
    post('setAutoPay', { enabled: autoPay.checked });
});

document.getElementById('techRefresh').addEventListener('click', () => post('refreshTech'));
document.getElementById('routeAll').addEventListener('click', () => post('routeRepairs'));
document.getElementById('clearRoute').addEventListener('click', () => post('clearRepairRoute'));

document.addEventListener('keyup', event => {
    if (event.key === 'Escape') post('close');
});
