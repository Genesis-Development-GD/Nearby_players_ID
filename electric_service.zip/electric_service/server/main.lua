local Framework = nil
local Grid = { version = 0, circuits = {} }
local callbacksRegistered = false
local ActiveRepairs = {}

local function GetFramework()
    if Framework then return Framework end

    local ok, object = pcall(function()
        return exports[Config.Framework.resource or 'es_extended']:getSharedObject()
    end)

    if ok and object then
        Framework = object
        return Framework
    end

    return Framework
end

local function Notify(source, message)
    if source == 0 then
        print(('[Electricidad] %s'):format(message))
        return
    end

    TriggerClientEvent('electric_service:client:notify', source, message)
end

local function SendChat(source, title, message)
    if source == 0 then
        print(('[%s] %s'):format(title, message))
        return
    end

    TriggerClientEvent('chat:addMessage', source, {
        color = { 80, 180, 255 },
        multiline = true,
        args = { title, message }
    })
end

local function ConcatArgs(args, startIndex)
    local result = {}
    for i = startIndex, #args do
        result[#result + 1] = args[i]
    end
    return table.concat(result, ' ')
end

local function GetState(circuitId)
    if not Grid.circuits[circuitId] then
        Grid.circuits[circuitId] = {
            status = 'online',
            health = 100,
            load = 0,
            outageUntil = 0,
            needsRepair = false,
            reason = '',
            failures = 0,
            updatedAt = os.time()
        }
    end

    return Grid.circuits[circuitId]
end

local function IsCircuitPowered(circuitId)
    local state = GetState(circuitId)
    return state.status == 'online' and (state.health or 0) > 0
end

local function ComputeLoad(circuit)
    local className = ElectricService.GetCircuitClass(circuit)
    local classDef = ElectricService.GetClassDefinition(className)
    local hour = tonumber(os.date('%H')) or 12
    local hourMultiplier = (Config.LoadModel.hourMultipliers or {})[hour] or 1.0
    local base = tonumber(circuit.baseLoad or 30) or 30
    local population = tonumber(circuit.populationWeight or 50) or 50
    local economic = tonumber(circuit.economicWeight or 50) or 50
    local classMultiplier = tonumber(classDef.demandMultiplier or 1.0) or 1.0
    local load = (base + (population * 0.22) + (economic * 0.28)) * hourMultiplier * classMultiplier

    return math.floor(math.min(200, load))
end

local function GetPublicCircuit(circuitOrId)
    local circuit = type(circuitOrId) == 'table' and circuitOrId or ElectricService.GetCircuitById(circuitOrId)
    if not circuit then return nil end

    local state = GetState(circuit.id)
    local className = ElectricService.GetCircuitClass(circuit)
    local classDef = ElectricService.GetClassDefinition(className)
    local coords = circuit.substation and circuit.substation.coords or vector3(0.0, 0.0, 0.0)

    return {
        id = circuit.id,
        name = circuit.name,
        priority = circuit.priority,
        economicWeight = circuit.economicWeight,
        populationWeight = circuit.populationWeight,
        importanceScore = ElectricService.GetImportanceScore(circuit),
        housingBasePrice = circuit.housingBasePrice,
        class = className,
        classLabel = classDef.label or className,
        classDescription = classDef.description or '',
        status = state.status,
        statusLabel = ElectricService.GetStatusLabel(state.status),
        powered = IsCircuitPowered(circuit.id),
        health = state.health or 0,
        load = state.load or ComputeLoad(circuit),
        capacity = circuit.capacity or 100,
        outageUntil = state.outageUntil or 0,
        needsRepair = state.needsRepair == true,
        reason = state.reason or '',
        failures = state.failures or 0,
        updatedAt = state.updatedAt or os.time(),
        substation = {
            label = circuit.substation and circuit.substation.label or circuit.id,
            x = coords.x,
            y = coords.y,
            z = coords.z
        },
        zones = circuit.zones or {}
    }
end

local function GetPublicGrid()
    local circuits = {}

    for _, circuit in ipairs(Config.Circuits or {}) do
        circuits[circuit.id] = GetPublicCircuit(circuit)
    end

    return {
        version = Grid.version,
        generatedAt = os.time(),
        circuits = circuits
    }
end

local function BroadcastGrid(target)
    TriggerClientEvent('electric_service:client:syncGrid', target or -1, GetPublicGrid())
end

local function SaveGrid()
    if not Config.Persistence.enabled then return end

    local data = {
        version = Grid.version,
        savedAt = os.time(),
        circuits = {}
    }

    for circuitId, state in pairs(Grid.circuits) do
        data.circuits[circuitId] = {
            status = state.status,
            health = state.health,
            load = state.load,
            outageUntil = state.outageUntil,
            needsRepair = state.needsRepair,
            reason = state.reason,
            failures = state.failures,
            updatedAt = state.updatedAt
        }
    end

    SaveResourceFile(GetCurrentResourceName(), Config.Persistence.file, json.encode(data), -1)
end

local function LoadGrid()
    Grid = { version = 1, circuits = {} }

    for _, circuit in ipairs(Config.Circuits or {}) do
        Grid.circuits[circuit.id] = {
            status = 'online',
            health = 100,
            load = ComputeLoad(circuit),
            outageUntil = 0,
            needsRepair = false,
            reason = '',
            failures = 0,
            updatedAt = os.time()
        }
    end

    if not Config.Persistence.enabled then return end

    local raw = LoadResourceFile(GetCurrentResourceName(), Config.Persistence.file)
    if not raw or raw == '' then return end

    local ok, saved = pcall(json.decode, raw)
    if not ok or not saved or type(saved.circuits) ~= 'table' then return end

    Grid.version = tonumber(saved.version or 1) or 1

    for circuitId, savedState in pairs(saved.circuits) do
        if Grid.circuits[circuitId] then
            Grid.circuits[circuitId].status = savedState.status or 'online'
            Grid.circuits[circuitId].health = tonumber(savedState.health or 100) or 100
            Grid.circuits[circuitId].load = tonumber(savedState.load or Grid.circuits[circuitId].load) or Grid.circuits[circuitId].load
            Grid.circuits[circuitId].outageUntil = tonumber(savedState.outageUntil or 0) or 0
            Grid.circuits[circuitId].needsRepair = savedState.needsRepair == true
            Grid.circuits[circuitId].reason = savedState.reason or ''
            Grid.circuits[circuitId].failures = tonumber(savedState.failures or 0) or 0
            Grid.circuits[circuitId].updatedAt = tonumber(savedState.updatedAt or os.time()) or os.time()

            if Grid.circuits[circuitId].status ~= 'online'
                and Grid.circuits[circuitId].outageUntil > 0
                and Grid.circuits[circuitId].outageUntil <= os.time()
                and not Grid.circuits[circuitId].needsRepair then
                Grid.circuits[circuitId].status = 'online'
                Grid.circuits[circuitId].health = 100
                Grid.circuits[circuitId].reason = ''
                Grid.circuits[circuitId].outageUntil = 0
            end
        end
    end
end

local function SetCircuitStatus(circuitId, status, minutes, reason, requiresRepair)
    local circuit = ElectricService.GetCircuitById(circuitId)
    if not circuit then return false, 'Circuito no encontrado.' end

    local state = GetState(circuit.id)
    local oldStatus = state.status
    local now = os.time()

    state.status = status
    state.reason = reason or ''
    state.updatedAt = now

    if status == 'online' then
        state.health = Config.Repair.restoreHealth or 100
        state.outageUntil = 0
        state.needsRepair = false
        state.reason = ''
    elseif status == 'offline' then
        state.health = math.min(tonumber(state.health or 100) or 100, 20)
        state.outageUntil = (tonumber(minutes or 0) or 0) > 0 and (now + ((tonumber(minutes) or 0) * 60)) or 0
        state.needsRepair = requiresRepair ~= false
        state.failures = (state.failures or 0) + 1
    elseif status == 'maintenance' then
        state.health = math.min(tonumber(state.health or 100) or 100, 80)
        state.outageUntil = (tonumber(minutes or 0) or 0) > 0 and (now + ((tonumber(minutes) or 0) * 60)) or 0
        state.needsRepair = false
    end

    Grid.version = Grid.version + 1
    SaveGrid()
    BroadcastGrid()

    local publicCircuit = GetPublicCircuit(circuit.id)
    TriggerClientEvent('electric_service:client:circuitChanged', -1, publicCircuit)
    TriggerEvent('electric_service:server:circuitChanged', circuit.id, status, oldStatus, publicCircuit)

    return true, 'Estado actualizado.'
end

local function ResolveCircuit(input)
    if not input then return nil end

    local circuit = ElectricService.GetCircuitById(input)
    if circuit then return circuit end

    local circuitId = ElectricService.GetCircuitIdByZone(input, false)
    if circuitId then
        return ElectricService.GetCircuitById(circuitId)
    end

    return nil
end

local function IsElectrician(xPlayer)
    if not Config.Repair.jobRequired then return true end
    if not xPlayer or not xPlayer.job then return false end

    local jobName = xPlayer.job.name
    local requiredGrade = Config.ElectricianJobs[jobName]
    if requiredGrade == nil then return false end

    local grade = tonumber(xPlayer.job.grade or 0) or 0
    return grade >= requiredGrade
end

local function GetPlayerCoords(source, fallbackCoords)
    local ped = GetPlayerPed(source)
    if ped and ped ~= 0 then
        local coords = GetEntityCoords(ped)
        if coords then return coords end
    end

    if fallbackCoords and fallbackCoords.x and fallbackCoords.y and fallbackCoords.z then
        return vector3(tonumber(fallbackCoords.x) or 0.0, tonumber(fallbackCoords.y) or 0.0, tonumber(fallbackCoords.z) or 0.0)
    end

    return nil
end

local function HasRequiredItem(xPlayer)
    if not Config.Repair.requiredItem then return true end
    if not xPlayer or not xPlayer.getInventoryItem then return false end

    local item = xPlayer.getInventoryItem(Config.Repair.requiredItem)
    return item and (tonumber(item.count or 0) or 0) > 0
end

local function CanRepair(source, circuitId, fallbackCoords)
    local framework = GetFramework()
    if not framework then return false, 'El framework no esta listo.' end

    local xPlayer = framework.GetPlayerFromId(source)
    if not xPlayer then return false, 'Jugador no encontrado.' end

    if not IsElectrician(xPlayer) then
        return false, 'No trabajas en el servicio electrico.'
    end

    if not HasRequiredItem(xPlayer) then
        return false, ('Necesitas %s.'):format(Config.Repair.requiredItem)
    end

    local circuit = ElectricService.GetCircuitById(circuitId)
    if not circuit then return false, 'Circuito no encontrado.' end

    local state = GetState(circuit.id)
    if state.status == 'online' and (state.health or 100) >= 100 then
        return false, 'Este circuito ya esta operativo.'
    end

    if not circuit.substation or not circuit.substation.coords then
        return false, 'Este circuito no tiene subestacion configurada.'
    end

    local coords = GetPlayerCoords(source, fallbackCoords)
    if not coords then return false, 'No se pudo validar tu posicion.' end

    local distance = #(coords - circuit.substation.coords)
    if distance > (Config.Repair.maxDistance or 4.0) then
        return false, 'Estas demasiado lejos de la subestacion.'
    end

    return true, 'Puedes reparar.', xPlayer, circuit, state
end

local function ComputeRepairPay(circuit)
    if not Config.Repair.pay.enabled then return 0 end

    local state = GetState(circuit.id)
    local priority = tonumber(circuit.priority or 5) or 5
    local base = tonumber(Config.Repair.pay.base or 0) or 0
    local priorityBonus = tonumber(Config.Repair.pay.priorityBonus or 0) or 0
    local loadDivider = tonumber(Config.Repair.pay.loadBonusDivider or 8) or 8
    local pay = base + ((6 - priority) * priorityBonus) + math.floor((state.load or 0) / loadDivider)

    return math.max(0, pay)
end

local function PayPlayer(xPlayer, amount)
    amount = tonumber(amount or 0) or 0
    if amount <= 0 then return end

    local account = Config.Repair.pay.account or 'bank'
    local ok = false

    if account == 'money' then
        ok = pcall(function() xPlayer.addMoney(amount) end)
    else
        ok = pcall(function() xPlayer.addAccountMoney(account, amount) end)
    end

    if not ok then
        pcall(function() xPlayer.addMoney(amount) end)
    end
end

local function RemoveRepairItem(xPlayer)
    if Config.Repair.requiredItem and Config.Repair.consumeItem and xPlayer.removeInventoryItem then
        xPlayer.removeInventoryItem(Config.Repair.requiredItem, 1)
    end
end

local function IsAdmin(source)
    if source == 0 then return true end

    if Config.Admin.ace and IsPlayerAceAllowed(source, Config.Admin.ace) then
        return true
    end

    local framework = GetFramework()
    local xPlayer = framework and framework.GetPlayerFromId(source) or nil
    if not xPlayer then return false end

    local group = nil
    if xPlayer.getGroup then
        local ok, value = pcall(function() return xPlayer.getGroup() end)
        if ok then group = value end
    end

    if group and Config.Admin.frameworkGroups[group] then
        return true
    end

    return false
end

local function RefreshLoads()
    local changed = false

    for _, circuit in ipairs(Config.Circuits or {}) do
        local state = GetState(circuit.id)
        local newLoad = ComputeLoad(circuit)

        if state.load ~= newLoad then
            state.load = newLoad
            changed = true
        end

        if state.status == 'online' then
            local capacity = tonumber(circuit.capacity or 100) or 100

            if newLoad > capacity then
                local damage = math.ceil((newLoad - capacity) / (Config.LoadModel.overloadDamageDivisor or 8))
                if damage > 0 then
                    state.health = math.max(0, (state.health or 100) - damage)
                    changed = true
                end

                if state.health <= 0 then
                    SetCircuitStatus(circuit.id, 'offline', 0, 'Sobrecarga del circuito', true)
                end
            elseif (state.health or 100) < 100 then
                state.health = math.min(100, (state.health or 100) + 1)
                changed = true
            end
        elseif (state.status == 'offline' or state.status == 'maintenance')
            and (state.outageUntil or 0) > 0
            and state.outageUntil <= os.time()
            and not state.needsRepair then
            SetCircuitStatus(circuit.id, 'online', 0, 'Restauracion automatica', false)
        end
    end

    if changed then
        Grid.version = Grid.version + 1
        SaveGrid()
        BroadcastGrid()
    end
end

local function PickRandomCircuitForOutage()
    local candidates = {}
    local totalWeight = 0.0

    for _, circuit in ipairs(Config.Circuits or {}) do
        local state = GetState(circuit.id)

        if state.status == 'online' then
            local className = ElectricService.GetCircuitClass(circuit)
            local classDef = ElectricService.GetClassDefinition(className)
            local reliability = tonumber(classDef.reliability or 0.90) or 0.90
            local capacity = tonumber(circuit.capacity or 100) or 100
            local loadRatio = capacity > 0 and ((state.load or 0) / capacity) or 0.0
            local baseWeight = math.max(1.0, (1.0 - reliability) * 100.0)
            local overloadWeight = math.max(0.0, loadRatio - 0.80) * 50.0
            local populationWeight = (tonumber(circuit.populationWeight or 0) or 0) / 25.0
            local economicWeight = (tonumber(circuit.economicWeight or 0) or 0) / 35.0
            local priorityFactor = 1.0

            if Config.RandomEvents.respectPriority then
                priorityFactor = 0.60 + ((tonumber(circuit.priority or 5) or 5) * 0.14)
            end

            local weight = (baseWeight + overloadWeight + populationWeight + economicWeight) * priorityFactor
            totalWeight = totalWeight + weight
            candidates[#candidates + 1] = { circuit = circuit, weight = weight }
        end
    end

    if totalWeight <= 0.0 then return nil end

    local roll = math.random() * totalWeight
    local cursor = 0.0

    for _, candidate in ipairs(candidates) do
        cursor = cursor + candidate.weight
        if roll <= cursor then
            return candidate.circuit
        end
    end

    return candidates[#candidates] and candidates[#candidates].circuit or nil
end

local function TryRandomOutage()
    if not Config.RandomEvents.enabled then return end
    if math.random() > (Config.RandomEvents.chanceBase or 0.10) then return end

    local circuit = PickRandomCircuitForOutage()
    if not circuit then return end

    local minMinutes = tonumber(Config.RandomEvents.minOfflineMinutes or 10) or 10
    local maxMinutes = tonumber(Config.RandomEvents.maxOfflineMinutes or 40) or 40
    if maxMinutes < minMinutes then maxMinutes = minMinutes end

    local minutes = math.random(minMinutes, maxMinutes)
    SetCircuitStatus(circuit.id, 'offline', minutes, 'Falla automatica de la red', Config.RandomEvents.requireRepair)
end


local Billing = {
    version = 0,
    calendar = {},
    properties = {},
    autoPay = {},
    autoPayAttempts = {},
    debtCircuits = {}
}

local GetBillingOverview

local function BillingEnabled()
    return Config.Billing and Config.Billing.enabled == true
end

local function Upper(value)
    if value == nil then return nil end
    return string.upper(tostring(value))
end

local function GetIdentifier(xPlayer)
    if not xPlayer then return nil end
    if xPlayer.identifier then return xPlayer.identifier end
    if xPlayer.getIdentifier then
        local ok, value = pcall(function() return xPlayer.getIdentifier() end)
        if ok then return value end
    end
    return nil
end

local function GetXPlayerByIdentifier(identifier)
    if not identifier then return nil, nil end
    local framework = GetFramework()
    if not framework then return nil, nil end

    for _, playerId in ipairs(GetPlayers()) do
        local source = tonumber(playerId)
        local xPlayer = framework.GetPlayerFromId(source)
        if xPlayer and GetIdentifier(xPlayer) == identifier then
            return xPlayer, source
        end
    end

    return nil, nil
end

local function GetBillingConfig()
    return Config.Billing or {}
end

local function GetCalendarConfig()
    local billing = GetBillingConfig()
    return billing.calendar or {}
end

local function GetInvoiceConfig()
    local billing = GetBillingConfig()
    return billing.invoice or {}
end

local function DaysPerMonth()
    local value = tonumber(GetCalendarConfig().daysPerMonth or 30) or 30
    return math.max(1, value)
end

local function CurrentCycleKey()
    local cal = Billing.calendar or {}
    return ('%04d-%02d'):format(tonumber(cal.year or 0) or 0, tonumber(cal.month or 0) or 0)
end

local function DaysUntilNextMonth()
    local cal = Billing.calendar or {}
    return math.max(0, DaysPerMonth() - (tonumber(cal.day or 1) or 1) + 1)
end

local function InitCalendar()
    local calendarConfig = GetCalendarConfig()

    Billing.calendar = Billing.calendar or {}
    Billing.calendar.day = tonumber(Billing.calendar.day or calendarConfig.startDay or 1) or 1
    Billing.calendar.month = tonumber(Billing.calendar.month or calendarConfig.startMonth or 1) or 1
    Billing.calendar.year = tonumber(Billing.calendar.year or calendarConfig.startYear or 2026) or 2026
    Billing.calendar.absoluteDay = tonumber(Billing.calendar.absoluteDay or 1) or 1
    Billing.calendar.lastTick = tonumber(Billing.calendar.lastTick or os.time()) or os.time()
end

local function ResolvePropertyCircuit(property)
    if property.circuitId and ElectricService.GetCircuitById(property.circuitId) then
        return property.circuitId
    end

    if property.zoneCode then
        local circuitId = ElectricService.GetCircuitIdByZone(property.zoneCode, true)
        if circuitId then return circuitId end
    end

    return Config.FallbackCircuit
end

local function ResolvePropertyClass(property)
    if property.class then return property.class end
    local circuitId = ResolvePropertyCircuit(property)
    local circuit = circuitId and ElectricService.GetCircuitById(circuitId) or nil
    if circuit then return ElectricService.GetCircuitClass(circuit) end
    return 'economica'
end

local function NormalizePropertyType(propertyType)
    propertyType = string.lower(tostring(propertyType or 'house'))
    if propertyType == 'vivienda' or propertyType == 'home' then return 'house' end
    if propertyType == 'negocio' or propertyType == 'businesses' then return 'business' end
    if propertyType ~= 'business' then return 'house' end
    return propertyType
end

local function CalculatePropertyFee(property)
    local billing = GetBillingConfig()
    local propertyType = NormalizePropertyType(property.type)

    if property.feeOverride then
        return math.max(0, math.floor(tonumber(property.feeOverride) or 0))
    end

    local zoneCode = Upper(property.zoneCode)
    local circuitId = property.circuitId
    local className = ResolvePropertyClass(property)
    local amount = nil

    if zoneCode and billing.feesByZone and billing.feesByZone[zoneCode] then
        amount = billing.feesByZone[zoneCode][propertyType]
    end

    if amount == nil and circuitId and billing.feesByCircuit and billing.feesByCircuit[circuitId] then
        amount = billing.feesByCircuit[circuitId][propertyType]
    end

    if amount == nil and billing.feesByClass and billing.feesByClass[className] then
        amount = billing.feesByClass[className][propertyType]
    end

    if amount == nil and billing.feesByClass and billing.feesByClass.economica then
        amount = billing.feesByClass.economica[propertyType]
    end

    local multiplier = tonumber(property.feeMultiplier or 1.0) or 1.0
    return math.max(0, math.floor((tonumber(amount or 0) or 0) * multiplier))
end

local function NormalizeProperty(raw, preserveBilling)
    raw = raw or {}
    if not raw.id then return nil, 'La propiedad necesita id.' end

    local id = tostring(raw.id)
    local existing = preserveBilling and Billing.properties[id] or nil
    local property = existing or {}

    property.id = id
    property.label = raw.label or property.label or id
    property.owner = raw.owner or raw.identifier or property.owner
    property.type = NormalizePropertyType(raw.type or property.type)
    property.zoneCode = Upper(raw.zoneCode or property.zoneCode)
    property.circuitId = raw.circuitId or property.circuitId
    property.class = raw.class or property.class
    property.feeOverride = raw.feeOverride ~= nil and tonumber(raw.feeOverride) or property.feeOverride
    property.feeMultiplier = tonumber(raw.feeMultiplier or property.feeMultiplier or 1.0) or 1.0
    if raw.coords then
        property.coords = {
            x = tonumber(raw.coords.x or raw.coords[1] or 0.0) or 0.0,
            y = tonumber(raw.coords.y or raw.coords[2] or 0.0) or 0.0,
            z = tonumber(raw.coords.z or raw.coords[3] or 0.0) or 0.0
        }
    end
    property.metadata = raw.metadata or property.metadata or {}

    property.circuitId = ResolvePropertyCircuit(property)
    property.class = ResolvePropertyClass(property)
    property.monthlyFee = CalculatePropertyFee(property)

    property.balance = tonumber(property.balance or 0) or 0
    property.lastInvoiceAmount = tonumber(property.lastInvoiceAmount or 0) or 0
    property.dueAbsoluteDay = tonumber(property.dueAbsoluteDay or 0) or 0
    property.lastBilledCycle = property.lastBilledCycle or nil
    property.lastPaidCycle = property.lastPaidCycle or nil
    property.lastPaidAt = tonumber(property.lastPaidAt or 0) or 0
    property.pending = property.balance > 0
    property.debt = property.debt == true
    property.debtAmount = tonumber(property.debtAmount or 0) or 0
    property.debtCircuitId = property.owner and ElectricService.GetDebtCircuitId(property.owner) or nil
    property.updatedAt = os.time()

    return property
end

local function OwnerHasDebt(identifier)
    if not identifier then return false end

    for _, property in pairs(Billing.properties or {}) do
        if property.owner == identifier and property.debt == true and (tonumber(property.balance or 0) or 0) > 0 then
            return true
        end
    end

    return false
end

local function IsPropertyDebtBlocked(property)
    if not property then return false end
    local invoiceConfig = GetInvoiceConfig()

    if invoiceConfig.cutAllOwnerPropertiesOnDebt and OwnerHasDebt(property.owner) then
        return true
    end

    return property.debt == true and (tonumber(property.balance or 0) or 0) > 0
end

local function GetPropertyPowerState(property)
    if not property then
        return {
            powered = false,
            zoneCircuitPowered = false,
            debtBlocked = false,
            reason = 'property_not_found'
        }
    end

    property.circuitId = ResolvePropertyCircuit(property)
    local zoneCircuitPowered = IsCircuitPowered(property.circuitId)
    local debtBlocked = IsPropertyDebtBlocked(property)
    local powered = zoneCircuitPowered and not debtBlocked
    local reason = 'online'

    if not zoneCircuitPowered then
        reason = 'zone_circuit_offline'
    elseif debtBlocked then
        reason = 'debt_cut'
    end

    return {
        powered = powered,
        zoneCircuitPowered = zoneCircuitPowered,
        debtBlocked = debtBlocked,
        reason = reason,
        circuitId = property.circuitId,
        debtCircuitId = property.debtCircuitId
    }
end

local function BuildDebtCircuits()
    local debtConfig = (GetBillingConfig().debtCircuit or {})
    local includeAll = GetInvoiceConfig().cutAllOwnerPropertiesOnDebt == true
    local ownerDebt = {}

    for _, property in pairs(Billing.properties or {}) do
        if property.owner and property.debt == true and (tonumber(property.balance or 0) or 0) > 0 then
            ownerDebt[property.owner] = true
        end
    end

    Billing.debtCircuits = {}

    for _, property in pairs(Billing.properties or {}) do
        if property.owner and ownerDebt[property.owner] and (includeAll or property.debt == true) then
            local owner = property.owner
            local debtCircuitId = ElectricService.GetDebtCircuitId(owner)
            property.debtCircuitId = debtCircuitId

            if not Billing.debtCircuits[owner] then
                Billing.debtCircuits[owner] = {
                    id = debtCircuitId,
                    owner = owner,
                    label = debtConfig.label or 'Circuito virtual de deuda',
                    status = debtConfig.statusWhenDebt or 'offline',
                    affectsZoneCircuits = false,
                    propertyIds = {},
                    debtAmount = 0,
                    updatedAt = os.time()
                }
            end

            local circuit = Billing.debtCircuits[owner]
            circuit.propertyIds[#circuit.propertyIds + 1] = property.id
            if property.debt == true then
                circuit.debtAmount = circuit.debtAmount + (tonumber(property.balance or 0) or 0)
            end
        end
    end
end

local function EvaluatePropertyDebts()
    local nowDay = tonumber(Billing.calendar.absoluteDay or 1) or 1
    local changed = false

    for _, property in pairs(Billing.properties or {}) do
        local oldDebt = property.debt == true
        local balance = tonumber(property.balance or 0) or 0
        local dueDay = tonumber(property.dueAbsoluteDay or 0) or 0

        if balance > 0 and dueDay > 0 and nowDay > dueDay then
            property.debt = true
            property.debtAmount = balance
        else
            if balance <= 0 then
                property.debt = false
                property.debtAmount = 0
            end
        end

        property.pending = balance > 0
        property.monthlyFee = CalculatePropertyFee(property)
        property.circuitId = ResolvePropertyCircuit(property)
        property.class = ResolvePropertyClass(property)

        if oldDebt ~= (property.debt == true) then
            changed = true
        end
    end

    BuildDebtCircuits()
    if changed then Billing.version = Billing.version + 1 end
    return changed
end

local function EnsureMonthlyInvoice(property)
    if not property or not property.owner then return false end

    local cycle = CurrentCycleKey()
    if property.lastBilledCycle == cycle then return false end

    local fee = CalculatePropertyFee(property)
    local previousBalance = tonumber(property.balance or 0) or 0

    property.balance = previousBalance + fee
    property.pending = property.balance > 0
    property.lastInvoiceAmount = fee
    property.lastBilledCycle = cycle
    property.lastInvoiceAtDay = Billing.calendar.absoluteDay
    property.updatedAt = os.time()

    if previousBalance <= 0 then
        local deadline = tonumber(GetInvoiceConfig().deadlineDays or DaysPerMonth()) or DaysPerMonth()
        property.dueAbsoluteDay = (tonumber(Billing.calendar.absoluteDay or 1) or 1) + math.max(1, deadline) - 1
    end

    property.monthlyFee = fee
    return true
end

local function GetTotalBalanceForOwner(identifier)
    local total = 0
    for _, property in pairs(Billing.properties or {}) do
        if property.owner == identifier then
            total = total + (tonumber(property.balance or 0) or 0)
        end
    end
    return math.max(0, math.floor(total))
end

local function GetAccountMoney(xPlayer, account)
    if not xPlayer then return 0 end

    if account == 'money' then
        if xPlayer.getMoney then
            return tonumber(xPlayer.getMoney()) or 0
        end
        return 0
    end

    if xPlayer.getAccount then
        local accountData = xPlayer.getAccount(account)
        if accountData then
            return tonumber(accountData.money or accountData.balance or 0) or 0
        end
    end

    return 0
end

local function RemoveAccountMoney(xPlayer, account, amount)
    amount = math.floor(tonumber(amount or 0) or 0)
    if amount <= 0 then return true end
    if not xPlayer then return false, 'Jugador no encontrado.' end

    local money = GetAccountMoney(xPlayer, account)
    if money >= amount then
        if account == 'money' then
            xPlayer.removeMoney(amount)
        else
            xPlayer.removeAccountMoney(account, amount)
        end
        return true
    end

    if GetBillingConfig().allowCashFallback and account ~= 'money' and GetAccountMoney(xPlayer, 'money') >= amount then
        xPlayer.removeMoney(amount)
        return true
    end

    return false, 'Fondos insuficientes.'
end

local function ClearOwnerBills(identifier)
    local cycle = CurrentCycleKey()
    local paidAt = os.time()

    for _, property in pairs(Billing.properties or {}) do
        if property.owner == identifier and (tonumber(property.balance or 0) or 0) > 0 then
            property.balance = 0
            property.pending = false
            property.debt = false
            property.debtAmount = 0
            property.dueAbsoluteDay = 0
            property.lastPaidCycle = cycle
            property.lastPaidAt = paidAt
            property.updatedAt = paidAt
        end
    end

    BuildDebtCircuits()
    Billing.version = Billing.version + 1
end

local function SendBillingUpdate(identifier)
    if not GetBillingOverview then return end
    local _, targetSource = GetXPlayerByIdentifier(identifier)
    if targetSource then
        TriggerClientEvent('electric_service:client:billingChanged', targetSource, GetBillingOverview(identifier, true))
    end
end

local function PayPendingBillsForPlayer(xPlayer, reason)
    local identifier = GetIdentifier(xPlayer)
    if not identifier then return false, 'No se pudo leer el identificador.', 0 end

    local total = GetTotalBalanceForOwner(identifier)
    if total <= 0 then
        ClearOwnerBills(identifier)
        return true, 'No hay facturas pendientes.', 0
    end

    local account = GetBillingConfig().paymentAccount or 'bank'
    local ok, message = RemoveAccountMoney(xPlayer, account, total)
    if not ok then
        return false, message or 'No se pudo pagar la factura.', total
    end

    ClearOwnerBills(identifier)
    SaveResourceFile(GetCurrentResourceName(), GetBillingConfig().persistenceFile or 'data/billing_state.json', json.encode(Billing), -1)
    SendBillingUpdate(identifier)

    return true, reason or 'Factura pagada.', total
end

local function TryAutoPayForIdentifier(identifier, scheduledOnly)
    if not Billing.autoPay[identifier] then return false end

    local autoPayDay = tonumber(GetInvoiceConfig().autoPayDay or 1) or 1
    if scheduledOnly and (tonumber(Billing.calendar.day or 1) or 1) ~= autoPayDay then
        return false
    end

    local xPlayer, targetSource = GetXPlayerByIdentifier(identifier)
    if not xPlayer then return false end

    local total = GetTotalBalanceForOwner(identifier)
    if total <= 0 then return false end

    local ok, message, paid = PayPendingBillsForPlayer(xPlayer, 'Pago automatico ejecutado.')
    if targetSource then
        if ok then
            Notify(targetSource, ('Pago automatico de electricidad: %s.'):format(ElectricService.FormatMoney(paid)))
        else
            Notify(targetSource, ('No se pudo ejecutar el pago automatico: %s'):format(message or 'error'))
        end
    end

    return ok
end

local function ProcessBillingDay()
    if not BillingEnabled() then return false end

    local changed = false

    for _, property in pairs(Billing.properties or {}) do
        if EnsureMonthlyInvoice(property) then
            changed = true
        end
    end

    if (tonumber(Billing.calendar.day or 1) or 1) == (tonumber(GetInvoiceConfig().autoPayDay or 1) or 1) then
        local cycle = CurrentCycleKey()
        Billing.autoPayAttempts = Billing.autoPayAttempts or {}

        for identifier, enabled in pairs(Billing.autoPay or {}) do
            if enabled and Billing.autoPayAttempts[identifier] ~= cycle then
                TryAutoPayForIdentifier(identifier, true)
                Billing.autoPayAttempts[identifier] = cycle
            end
        end
    end

    if EvaluatePropertyDebts() then
        changed = true
    end

    if changed then
        Billing.version = Billing.version + 1
    end

    return changed
end

local function AdvanceCalendar(days)
    days = math.floor(tonumber(days or 0) or 0)
    if days <= 0 then return false end

    local changed = false
    local daysPerMonth = DaysPerMonth()

    for _ = 1, days do
        Billing.calendar.absoluteDay = (tonumber(Billing.calendar.absoluteDay or 1) or 1) + 1
        Billing.calendar.day = (tonumber(Billing.calendar.day or 1) or 1) + 1

        if Billing.calendar.day > daysPerMonth then
            Billing.calendar.day = 1
            Billing.calendar.month = (tonumber(Billing.calendar.month or 1) or 1) + 1

            if Billing.calendar.month > 12 then
                Billing.calendar.month = 1
                Billing.calendar.year = (tonumber(Billing.calendar.year or 2026) or 2026) + 1
            end
        end

        if ProcessBillingDay() then
            changed = true
        end
    end

    if changed then Billing.version = Billing.version + 1 end
    return changed
end

local function RefreshBillingCalendar()
    if not BillingEnabled() then return false end
    InitCalendar()

    local secondsPerDay = tonumber(GetCalendarConfig().realSecondsPerGameDay or 300) or 300
    secondsPerDay = math.max(1, secondsPerDay)

    local now = os.time()
    local lastTick = tonumber(Billing.calendar.lastTick or now) or now
    local elapsedDays = math.floor((now - lastTick) / secondsPerDay)

    if elapsedDays <= 0 then
        return false
    end

    if elapsedDays > 3650 then elapsedDays = 3650 end
    Billing.calendar.lastTick = lastTick + (elapsedDays * secondsPerDay)

    local changed = AdvanceCalendar(elapsedDays)
    if changed then
        SaveResourceFile(GetCurrentResourceName(), GetBillingConfig().persistenceFile or 'data/billing_state.json', json.encode(Billing), -1)
    end

    return changed
end

local function SaveBilling()
    if not BillingEnabled() then return end
    local billing = GetBillingConfig()
    SaveResourceFile(GetCurrentResourceName(), billing.persistenceFile or 'data/billing_state.json', json.encode(Billing), -1)
end

local function RegisterBillingProperty(raw, preserveBilling)
    if not BillingEnabled() then return false, 'Facturacion desactivada.' end
    InitCalendar()

    local property, err = NormalizeProperty(raw, preserveBilling ~= false)
    if not property then return false, err or 'Propiedad no valida.' end

    local isNew = Billing.properties[property.id] == nil
    Billing.properties[property.id] = property

    if isNew and GetInvoiceConfig().graceOnRegistration then
        property.lastBilledCycle = property.lastBilledCycle or CurrentCycleKey()
    else
        EnsureMonthlyInvoice(property)
    end

    EvaluatePropertyDebts()
    Billing.version = Billing.version + 1
    SaveBilling()
    SendBillingUpdate(property.owner)

    return true, 'Propiedad registrada.', property
end

local function RemoveBillingProperty(propertyId)
    propertyId = tostring(propertyId or '')
    local property = Billing.properties[propertyId]
    if not property then return false, 'Propiedad no encontrada.' end

    local owner = property.owner
    Billing.properties[propertyId] = nil
    EvaluatePropertyDebts()
    Billing.version = Billing.version + 1
    SaveBilling()
    SendBillingUpdate(owner)

    return true, 'Propiedad eliminada.'
end

local function LoadBilling()
    Billing = {
        version = 1,
        calendar = {},
        properties = {},
        autoPay = {},
        autoPayAttempts = {},
        debtCircuits = {}
    }

    if not BillingEnabled() then return end

    local raw = LoadResourceFile(GetCurrentResourceName(), GetBillingConfig().persistenceFile or 'data/billing_state.json')
    if raw and raw ~= '' then
        local ok, saved = pcall(json.decode, raw)
        if ok and saved and type(saved) == 'table' then
            Billing.version = tonumber(saved.version or 1) or 1
            Billing.calendar = type(saved.calendar) == 'table' and saved.calendar or {}
            Billing.properties = type(saved.properties) == 'table' and saved.properties or {}
            Billing.autoPay = type(saved.autoPay) == 'table' and saved.autoPay or {}
            Billing.autoPayAttempts = type(saved.autoPayAttempts) == 'table' and saved.autoPayAttempts or {}
            Billing.debtCircuits = type(saved.debtCircuits) == 'table' and saved.debtCircuits or {}
        end
    end

    InitCalendar()

    local normalized = {}
    for propertyId, property in pairs(Billing.properties or {}) do
        property.id = property.id or propertyId
        local normalizedProperty = NormalizeProperty(property, true)
        if normalizedProperty then
            normalized[normalizedProperty.id] = normalizedProperty
        end
    end
    Billing.properties = normalized

    for _, property in ipairs(GetBillingConfig().registeredProperties or {}) do
        RegisterBillingProperty(property, true)
    end

    ProcessBillingDay()
    EvaluatePropertyDebts()
    SaveBilling()
end

local function DaysLeftForProperty(property)
    local balance = tonumber(property.balance or 0) or 0
    if balance <= 0 then
        return DaysUntilNextMonth()
    end

    local currentDay = tonumber(Billing.calendar.absoluteDay or 1) or 1
    local dueDay = tonumber(property.dueAbsoluteDay or currentDay) or currentDay
    return math.max(0, dueDay - currentDay + 1)
end

local function GetPublicProperty(property)
    if not property then return nil end

    property.monthlyFee = CalculatePropertyFee(property)
    property.circuitId = ResolvePropertyCircuit(property)
    property.class = ResolvePropertyClass(property)
    property.debtCircuitId = property.owner and ElectricService.GetDebtCircuitId(property.owner) or nil

    local classDef = ElectricService.GetClassDefinition(property.class)
    local power = GetPropertyPowerState(property)
    local balance = tonumber(property.balance or 0) or 0

    return {
        id = property.id,
        label = property.label or property.id,
        owner = property.owner,
        type = property.type,
        typeLabel = ElectricService.GetPropertyTypeLabel(property.type),
        zoneCode = property.zoneCode,
        circuitId = property.circuitId,
        class = property.class,
        classLabel = classDef.label or property.class,
        monthlyFee = property.monthlyFee,
        balance = balance,
        pending = balance > 0,
        debt = property.debt == true,
        debtAmount = tonumber(property.debtAmount or 0) or 0,
        debtCircuitId = property.debtCircuitId,
        daysLeft = DaysLeftForProperty(property),
        dueAbsoluteDay = property.dueAbsoluteDay or 0,
        lastInvoiceAmount = property.lastInvoiceAmount or 0,
        lastBilledCycle = property.lastBilledCycle,
        lastPaidCycle = property.lastPaidCycle,
        powered = power.powered,
        zoneCircuitPowered = power.zoneCircuitPowered,
        debtBlocked = power.debtBlocked,
        powerReason = power.reason
    }
end

GetBillingOverview = function(identifier, skipRefresh)
    if not BillingEnabled() then
        return { enabled = false, properties = {}, totalDue = 0 }
    end

    if not skipRefresh then
        RefreshBillingCalendar()
        ProcessBillingDay()
        EvaluatePropertyDebts()
    end

    local properties = {}
    local totalDue = 0
    local minDaysLeft = nil
    local hasDebt = false

    for _, property in pairs(Billing.properties or {}) do
        if property.owner == identifier then
            local publicProperty = GetPublicProperty(property)
            properties[#properties + 1] = publicProperty
            totalDue = totalDue + (tonumber(publicProperty.balance or 0) or 0)
            if publicProperty.pending then
                minDaysLeft = minDaysLeft and math.min(minDaysLeft, publicProperty.daysLeft) or publicProperty.daysLeft
            end
            if publicProperty.debt then hasDebt = true end
        end
    end

    table.sort(properties, function(a, b)
        return tostring(a.label or a.id) < tostring(b.label or b.id)
    end)

    local debtCircuit = Billing.debtCircuits[identifier]
    if not debtCircuit then
        debtCircuit = {
            id = ElectricService.GetDebtCircuitId(identifier),
            owner = identifier,
            label = (GetBillingConfig().debtCircuit or {}).label or 'Circuito virtual de deuda',
            status = (GetBillingConfig().debtCircuit or {}).statusWhenClear or 'online',
            affectsZoneCircuits = false,
            propertyIds = {},
            debtAmount = 0
        }
    end

    return {
        enabled = true,
        version = Billing.version,
        identifier = identifier,
        calendar = {
            day = Billing.calendar.day,
            month = Billing.calendar.month,
            year = Billing.calendar.year,
            absoluteDay = Billing.calendar.absoluteDay,
            daysPerMonth = DaysPerMonth()
        },
        properties = properties,
        totalDue = math.floor(totalDue),
        formattedTotalDue = ElectricService.FormatMoney(totalDue),
        daysLeft = minDaysLeft or DaysUntilNextMonth(),
        hasDebt = hasDebt,
        autoPay = Billing.autoPay[identifier] == true,
        paymentAccount = GetBillingConfig().paymentAccount or 'bank',
        debtCircuit = debtCircuit
    }
end

local function GetSourceBillingOverview(source)
    local framework = GetFramework()
    local xPlayer = framework and framework.GetPlayerFromId(source) or nil
    local identifier = GetIdentifier(xPlayer)
    if not identifier then return { enabled = BillingEnabled(), properties = {}, totalDue = 0 } end
    return GetBillingOverview(identifier)
end


local function GetRepairOutageCircuits()
    local circuits = {}

    for _, circuit in ipairs(Config.Circuits or {}) do
        local state = GetState(circuit.id)
        local isFailure = state.status == 'offline' and state.needsRepair == true
        local includeCircuit = isFailure

        if Config.RepairApp and Config.RepairApp.showOnlyFailureOutages == false then
            includeCircuit = state.status ~= 'online' and state.needsRepair == true
        end

        if includeCircuit then
            circuits[#circuits + 1] = GetPublicCircuit(circuit.id)
        end
    end

    table.sort(circuits, function(a, b)
        local ap = tonumber(a.priority or 5) or 5
        local bp = tonumber(b.priority or 5) or 5
        if ap == bp then
            return tostring(a.id or '') < tostring(b.id or '')
        end
        return ap < bp
    end)

    return circuits
end

local function GetElectricianDashboard(source)
    if not Config.RepairApp or Config.RepairApp.enabled == false then
        return { ok = false, message = 'La app tecnica esta desactivada.', circuits = {} }
    end

    local framework = GetFramework()
    local xPlayer = framework and framework.GetPlayerFromId(source) or nil

    if not IsElectrician(xPlayer) then
        return { ok = false, message = 'No trabajas en el servicio electrico.', circuits = {} }
    end

    local circuits = GetRepairOutageCircuits()

    return {
        ok = true,
        title = (Config.RepairApp and Config.RepairApp.title) or 'Panel tecnico electrico',
        generatedAt = os.time(),
        gridVersion = Grid.version,
        count = #circuits,
        circuits = circuits
    }
end

local function RegisterCallbacks()
    if callbacksRegistered then return end

    local framework = GetFramework()
    if not framework then return end

    framework.RegisterServerCallback('electric_service:server:getGrid', function(source, cb)
        cb(GetPublicGrid())
    end)

    framework.RegisterServerCallback('electric_service:server:getElectricianDashboard', function(source, cb)
        cb(GetElectricianDashboard(source))
    end)

    framework.RegisterServerCallback('electric_service:server:canRepair', function(source, cb, circuitId, coords)
        local ok, message, xPlayer, circuit = CanRepair(source, circuitId, coords)

        if ok and circuit then
            ActiveRepairs[source] = {
                circuitId = circuit.id,
                startedAt = os.time(),
                expiresAt = os.time() + math.ceil((Config.Repair.durationMs or 18000) / 1000) + 20,
                fallbackCoords = coords
            }
        end

        cb({
            ok = ok,
            message = message,
            duration = Config.Repair.durationMs,
            circuit = GetPublicCircuit(circuitId)
        })
    end)

    framework.RegisterServerCallback('electric_service:server:getBillingOverview', function(source, cb)
        cb(GetSourceBillingOverview(source))
    end)

    framework.RegisterServerCallback('electric_service:server:payPendingBills', function(source, cb)
        local xPlayer = framework.GetPlayerFromId(source)
        local ok, message, paid = PayPendingBillsForPlayer(xPlayer, 'Factura pagada correctamente.')
        if ok then SaveBilling() end
        cb({
            ok = ok,
            message = message,
            paid = paid or 0,
            overview = GetSourceBillingOverview(source)
        })
    end)

    framework.RegisterServerCallback('electric_service:server:setAutoPay', function(source, cb, enabled)
        local xPlayer = framework.GetPlayerFromId(source)
        local identifier = GetIdentifier(xPlayer)
        if not identifier then
            cb({ ok = false, message = 'No se pudo leer el identificador.' })
            return
        end

        Billing.autoPay[identifier] = enabled == true
        Billing.version = Billing.version + 1
        SaveBilling()

        if Billing.autoPay[identifier] then
            TryAutoPayForIdentifier(identifier, false)
        end

        cb({
            ok = true,
            message = Billing.autoPay[identifier] and 'Pago automatico activado.' or 'Pago automatico desactivado.',
            overview = GetBillingOverview(identifier)
        })
    end)

    framework.RegisterServerCallback('electric_service:server:getPropertyPower', function(source, cb, propertyId)
        propertyId = tostring(propertyId or '')
        local property = Billing.properties[propertyId]
        if not property then
            cb({ ok = false, message = 'Propiedad no encontrada.', powered = false })
            return
        end

        local xPlayer = framework.GetPlayerFromId(source)
        local identifier = GetIdentifier(xPlayer)
        if property.owner ~= identifier and not IsAdmin(source) then
            cb({ ok = false, message = 'No eres propietario de esta propiedad.', powered = false })
            return
        end

        local state = GetPropertyPowerState(property)
        state.ok = true
        state.property = GetPublicProperty(property)
        cb(state)
    end)

    callbacksRegistered = true
end

RegisterNetEvent('electric_service:server:finishRepair', function(circuitId)
    local source = source
    local session = ActiveRepairs[source]

    if not session or session.circuitId ~= circuitId or session.expiresAt < os.time() then
        ActiveRepairs[source] = nil
        Notify(source, 'La reparacion ya no es valida.')
        return
    end

    local ok, message, xPlayer, circuit = CanRepair(source, circuitId, session.fallbackCoords)
    ActiveRepairs[source] = nil

    if not ok then
        Notify(source, message)
        return
    end

    RemoveRepairItem(xPlayer)

    local pay = ComputeRepairPay(circuit)
    SetCircuitStatus(circuit.id, 'online', 0, ('Reparado por %s'):format(GetPlayerName(source) or tostring(source)), false)
    PayPlayer(xPlayer, pay)

    if pay > 0 then
        Notify(source, ('Circuito reparado. Pago recibido: %s'):format(ElectricService.FormatMoney(pay)))
    else
        Notify(source, 'Circuito reparado.')
    end
end)

RegisterCommand(Config.Commands.adminOutage, function(source, args)
    if not IsAdmin(source) then
        Notify(source, 'No tienes permisos para usar este comando.')
        return
    end

    local circuit = ResolveCircuit(args[1])
    if not circuit then
        Notify(source, 'Uso: /corte <circuito|zona> [minutos] [motivo]')
        return
    end

    local minutes = tonumber(args[2] or 0) or 0
    local reason = ConcatArgs(args, 3)
    if reason == '' then reason = 'Corte manual' end

    local ok, message = SetCircuitStatus(circuit.id, 'offline', minutes, reason, true)
    Notify(source, ok and ('Corte aplicado en %s.'):format(circuit.id) or message)
end, false)

RegisterCommand(Config.Commands.adminRestore, function(source, args)
    if not IsAdmin(source) then
        Notify(source, 'No tienes permisos para usar este comando.')
        return
    end

    local circuit = ResolveCircuit(args[1])
    if not circuit then
        Notify(source, 'Uso: /restaurar <circuito|zona>')
        return
    end

    local ok, message = SetCircuitStatus(circuit.id, 'online', 0, 'Restauracion manual', false)
    Notify(source, ok and ('Servicio restaurado en %s.'):format(circuit.id) or message)
end, false)

RegisterCommand(Config.Commands.adminMaintenance, function(source, args)
    if not IsAdmin(source) then
        Notify(source, 'No tienes permisos para usar este comando.')
        return
    end

    local circuit = ResolveCircuit(args[1])
    if not circuit then
        Notify(source, 'Uso: /mantenimiento <circuito|zona> <on|off> [minutos] [motivo]')
        return
    end

    local mode = args[2] or 'on'

    if mode == 'off' then
        local ok, message = SetCircuitStatus(circuit.id, 'online', 0, 'Fin de mantenimiento', false)
        Notify(source, ok and ('Mantenimiento finalizado en %s.'):format(circuit.id) or message)
        return
    end

    local minutes = tonumber(args[3] or 0) or 0
    local reason = ConcatArgs(args, 4)
    if reason == '' then reason = 'Mantenimiento programado' end

    local ok, message = SetCircuitStatus(circuit.id, 'maintenance', minutes, reason, false)
    Notify(source, ok and ('Mantenimiento aplicado en %s.'):format(circuit.id) or message)
end, false)

RegisterCommand(Config.Commands.adminGrid, function(source)
    if source ~= 0 and not IsAdmin(source) then
        Notify(source, 'No tienes permisos para usar este comando.')
        return
    end

    SendChat(source, 'Red electrica', ('Version: %s | Circuitos: %s'):format(Grid.version, tostring(#(Config.Circuits or {}))))

    for _, circuit in ipairs(Config.Circuits or {}) do
        local publicCircuit = GetPublicCircuit(circuit.id)
        SendChat(source, 'Red electrica', ('%s | %s | %s | clase %s | carga %s/%s | salud %s%%'):format(
            publicCircuit.id,
            publicCircuit.name,
            publicCircuit.statusLabel,
            publicCircuit.classLabel,
            tostring(publicCircuit.load),
            tostring(publicCircuit.capacity),
            tostring(publicCircuit.health)
        ))
    end
end, false)


RegisterCommand(Config.Commands.adminPropertyAdd, function(source, args)
    if source ~= 0 and not IsAdmin(source) then
        Notify(source, 'No tienes permisos para usar este comando.')
        return
    end

    local targetId = tonumber(args[1] or 0) or 0
    local propertyType = args[2]
    local propertyId = args[3]
    local zoneCode = args[4]
    local label = ConcatArgs(args, 5)

    if targetId <= 0 or not propertyType or not propertyId or not zoneCode then
        Notify(source, 'Uso: /electricidad_prop_add <idJugador> <house|business> <propiedadId> <zonaGTA> [nombre]')
        return
    end

    local framework = GetFramework()
    local target = framework and framework.GetPlayerFromId(targetId) or nil
    if not target then
        Notify(source, 'Jugador destino no encontrado.')
        return
    end

    local identifier = GetIdentifier(target)
    local ok, message, property = RegisterBillingProperty({
        id = propertyId,
        owner = identifier,
        type = propertyType,
        zoneCode = zoneCode,
        label = label ~= '' and label or propertyId
    }, true)

    if ok then
        Notify(source, ('Propiedad %s registrada en %s. Cuota: %s.'):format(property.id, property.circuitId or 'N/A', ElectricService.FormatMoney(property.monthlyFee or 0)))
        Notify(targetId, ('Servicio electrico registrado para %s.'):format(property.label or property.id))
    else
        Notify(source, message)
    end
end, false)

RegisterCommand(Config.Commands.adminPropertyRemove, function(source, args)
    if source ~= 0 and not IsAdmin(source) then
        Notify(source, 'No tienes permisos para usar este comando.')
        return
    end

    local propertyId = args[1]
    if not propertyId then
        Notify(source, 'Uso: /electricidad_prop_remove <propiedadId>')
        return
    end

    local ok, message = RemoveBillingProperty(propertyId)
    Notify(source, message)
end, false)

RegisterCommand(Config.Commands.adminPropertyStatus, function(source, args)
    if source ~= 0 and not IsAdmin(source) then
        Notify(source, 'No tienes permisos para usar este comando.')
        return
    end

    local propertyId = tostring(args[1] or '')
    local property = Billing.properties[propertyId]
    if not property then
        Notify(source, 'Uso: /electricidad_prop_estado <propiedadId>')
        return
    end

    local publicProperty = GetPublicProperty(property)
    SendChat(source, 'Propiedad electrica', ('%s | propietario %s | tipo %s | circuito %s | deuda %s | dias %s | energia %s | motivo %s'):format(
        publicProperty.label,
        publicProperty.owner or 'N/A',
        publicProperty.typeLabel,
        publicProperty.circuitId or 'N/A',
        ElectricService.FormatMoney(publicProperty.balance or 0),
        tostring(publicProperty.daysLeft or 0),
        publicProperty.powered and 'ON' or 'OFF',
        publicProperty.powerReason or 'N/A'
    ))

    if publicProperty.debtCircuitId then
        SendChat(source, 'Propiedad electrica', ('Circuito virtual: %s | no modifica el circuito zonal %s.'):format(publicProperty.debtCircuitId, publicProperty.circuitId or 'N/A'))
    end
end, false)

RegisterCommand(Config.Commands.adminBillingStatus, function(source, args)
    if source ~= 0 and not IsAdmin(source) then
        Notify(source, 'No tienes permisos para usar este comando.')
        return
    end

    local target = args[1]
    local identifier = target

    if target and tonumber(target) then
        local framework = GetFramework()
        local xPlayer = framework and framework.GetPlayerFromId(tonumber(target)) or nil
        identifier = GetIdentifier(xPlayer)
    end

    if not identifier then
        Notify(source, 'Uso: /electricidad_facturas <idJugador|identifier>')
        return
    end

    local overview = GetBillingOverview(identifier)
    SendChat(source, 'Facturacion electrica', ('Propietario: %s | deuda total: %s | dias restantes: %s | autopago: %s | circuito deuda: %s/%s'):format(
        identifier,
        ElectricService.FormatMoney(overview.totalDue or 0),
        tostring(overview.daysLeft or 0),
        overview.autoPay and 'ON' or 'OFF',
        overview.debtCircuit and overview.debtCircuit.id or 'N/A',
        overview.debtCircuit and overview.debtCircuit.status or 'N/A'
    ))

    for _, property in ipairs(overview.properties or {}) do
        SendChat(source, 'Facturacion electrica', ('%s | %s | cuota %s | pendiente %s | energia %s | zona %s'):format(
            property.id,
            property.typeLabel,
            ElectricService.FormatMoney(property.monthlyFee or 0),
            ElectricService.FormatMoney(property.balance or 0),
            property.powered and 'ON' or 'OFF',
            property.circuitId or 'N/A'
        ))
    end
end, false)

RegisterNetEvent('electric_service:server:requestBillingOverview', function()
    local source = source
    TriggerClientEvent('electric_service:client:billingChanged', source, GetSourceBillingOverview(source))
end)

RegisterNetEvent('electric_service:server:requestGrid', function()
    BroadcastGrid(source)
end)

CreateThread(function()
    math.randomseed(os.time())
    LoadGrid()
    LoadBilling()

    while not callbacksRegistered do
        RegisterCallbacks()
        Wait(500)
    end

    Wait(1500)
    BroadcastGrid()
end)

CreateThread(function()
    while true do
        Wait((Config.LoadModel.refreshSeconds or 60) * 1000)
        RefreshLoads()
    end
end)

CreateThread(function()
    while true do
        Wait((Config.RandomEvents.checkEveryMinutes or 15) * 60000)
        TryRandomOutage()
    end
end)

CreateThread(function()
    while true do
        Wait((Config.Persistence.saveEverySeconds or 120) * 1000)
        SaveGrid()
    end
end)

CreateThread(function()
    while true do
        Wait(30000)
        RefreshBillingCalendar()
        ProcessBillingDay()
    end
end)

CreateThread(function()
    while true do
        Wait(((Config.Billing and Config.Billing.saveEverySeconds) or 120) * 1000)
        SaveBilling()
    end
end)

exports('GetGrid', function()
    return GetPublicGrid()
end)

exports('GetCircuitState', function(circuitId)
    return GetPublicCircuit(circuitId)
end)

exports('IsCircuitPowered', function(circuitId)
    return IsCircuitPowered(circuitId)
end)

exports('GetCircuitFromZone', function(zoneCode)
    local circuit = ElectricService.GetCircuitByZone(zoneCode, true)
    return circuit and GetPublicCircuit(circuit.id) or nil
end)

exports('SetCircuitOffline', function(circuitId, minutes, reason, requiresRepair)
    return SetCircuitStatus(circuitId, 'offline', minutes or 0, reason or 'Corte desde export', requiresRepair ~= false)
end)

exports('SetCircuitOnline', function(circuitId, reason)
    return SetCircuitStatus(circuitId, 'online', 0, reason or 'Restauracion desde export', false)
end)

exports('SetCircuitMaintenance', function(circuitId, minutes, reason)
    return SetCircuitStatus(circuitId, 'maintenance', minutes or 0, reason or 'Mantenimiento desde export', false)
end)


exports('RegisterProperty', function(propertyData)
    return RegisterBillingProperty(propertyData, true)
end)

exports('RemoveProperty', function(propertyId)
    return RemoveBillingProperty(propertyId)
end)

exports('GetBillingOverview', function(identifier)
    return GetBillingOverview(identifier)
end)

exports('GetPropertyStatus', function(propertyId)
    local property = Billing.properties[tostring(propertyId or '')]
    return property and GetPublicProperty(property) or nil
end)

exports('IsPropertyPowered', function(propertyId)
    local property = Billing.properties[tostring(propertyId or '')]
    if not property then return false end
    return GetPropertyPowerState(property).powered == true
end)

exports('PayPlayerElectricBills', function(source)
    local framework = GetFramework()
    local xPlayer = framework and framework.GetPlayerFromId(source) or nil
    return PayPendingBillsForPlayer(xPlayer, 'Factura pagada desde export.')
end)

exports('SetPlayerAutoPay', function(identifier, enabled)
    if not identifier then return false end
    Billing.autoPay[identifier] = enabled == true
    Billing.version = Billing.version + 1
    SaveBilling()
    return true
end)

exports('GetRepairOutages', function()
    return GetRepairOutageCircuits()
end)

exports('GetDebtCircuit', function(identifier)
    return Billing.debtCircuits[identifier] or {
        id = ElectricService.GetDebtCircuitId(identifier),
        owner = identifier,
        status = (GetBillingConfig().debtCircuit or {}).statusWhenClear or 'online',
        affectsZoneCircuits = false,
        propertyIds = {},
        debtAmount = 0
    }
end)

AddEventHandler('playerDropped', function()
    ActiveRepairs[source] = nil
end)
